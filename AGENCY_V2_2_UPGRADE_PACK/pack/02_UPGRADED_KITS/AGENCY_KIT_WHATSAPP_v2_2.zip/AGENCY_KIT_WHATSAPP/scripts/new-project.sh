#!/usr/bin/env bash
# Agency Kit WHATSAPP — new WhatsApp bot project bootstrap
# Usage: ./scripts/new-project.sh <project-slug> [client-name] [single|multi-tenant]
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <project-slug> [\"Client Name\"] [single|multi]"
  echo "Example: $0 sunrise-dental-whatsapp \"Sunrise Dental\" single"
  exit 1
fi

SLUG="$1"
CLIENT_NAME="${2:-$SLUG}"
TENANCY="${3:-single}"
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET_DIR="../${SLUG}"

if [[ -d "$TARGET_DIR" ]]; then
  echo "Error: $TARGET_DIR already exists. Aborting."
  exit 1
fi

case "$TENANCY" in single|multi) ;; *) echo "Tenancy must be single or multi"; exit 1 ;; esac

echo "[1/9] Creating project: $TARGET_DIR (tenancy=$TENANCY)"
mkdir -p "$TARGET_DIR" && cd "$TARGET_DIR"

echo "[2/9] Next.js 14 admin shell"
pnpm create next-app@latest . --typescript --tailwind --eslint --app --src-dir --import-alias "@/*" --use-pnpm --no-turbo

echo "[3/9] Core deps + WhatsApp deps"
pnpm add @supabase/supabase-js @supabase/ssr @anthropic-ai/sdk zod @upstash/ratelimit @upstash/redis pino pino-pretty
pnpm add axios  # WhatsApp Cloud API — no official SDK; HTTP client
pnpm add -D @types/node tsx vitest @vitest/ui @testing-library/react @testing-library/jest-dom playwright

echo "[4/9] Copying kit (CLAUDE.md, rules, skills, agents, memory)"
cp "$KIT_DIR/CLAUDE.md" .
cp -r "$KIT_DIR/.claude" .
cp -r "$KIT_DIR/rules" .
cp "$KIT_DIR/settings.json" .claude/

echo "[5/9] progress.md"
cat > progress.md <<EOF
# PROGRESS — ${CLIENT_NAME} WhatsApp bot (${SLUG})
**Status:** scaffolded · **Tenancy:** ${TENANCY} · **Last updated:** $(date -u +"%Y-%m-%d %H:%M UTC")
**Build order:** DB → Webhook + send infra → Templates → Flows → Admin UI → Quality monitoring
## Completed
- [x] Step 00: Scaffolded with Agency Kit WhatsApp (${TENANCY}-tenant)
## Up next
- [ ] Step 01: Fill client_context.md (business, niche, language, hours, opt-in source)
- [ ] Step 02: Supabase project + WhatsApp Cloud API setup (BSP-managed or direct) + .env.local
- [ ] Step 03: DB schema (contacts, conversations, messages, templates, opt_ins, quality_rating_history$([ "$TENANCY" = "multi" ] && echo ", tenants"))
- [ ] Step 04: Gate A (DB) + cross-tenant RLS (if multi-tenant)
- [ ] Step 05: Webhook + send infra (signed inbound, idempotent send, retries)
- [ ] Step 06: Gate B (webhook + send routes)
- [ ] Step 07: Submit Day-1 niche templates (Section 28 of v2.1) → Gate F
- [ ] Step 08: Build Flows (booking + intake) → Gate H
- [ ] Step 09: Admin UI + quality dashboard → Gate C
- [ ] Step 10: Security audit → Gate D + 5 injection tests
- [ ] Step 11: Deploy → Gate E + Gate G (quality monitoring active)
EOF

echo "[6/9] .env.local template"
cat > .env.local.example <<'EOF'
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
# Anthropic
ANTHROPIC_API_KEY=
# WhatsApp Cloud API
WHATSAPP_ACCESS_TOKEN=
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_BUSINESS_ACCOUNT_ID=
WHATSAPP_VERIFY_TOKEN=
WHATSAPP_APP_SECRET=
WHATSAPP_API_VERSION=v20.0
# WhatsApp Flows (if used)
WHATSAPP_FLOWS_PRIVATE_KEY_PEM=
WHATSAPP_FLOWS_PASSPHRASE=
# WhatsApp Pay (if used, India)
WHATSAPP_PAY_MERCHANT_ID=
# Click-to-WhatsApp Ads (if used)
META_CAPI_ACCESS_TOKEN=
META_PIXEL_ID=
# Infra
UPSTASH_REDIS_REST_URL=
UPSTASH_REDIS_REST_TOKEN=
SENTRY_DSN=
LANGFUSE_PUBLIC_KEY=
LANGFUSE_SECRET_KEY=
LANGFUSE_HOST=https://cloud.langfuse.com
EOF
cp .env.local.example .env.local
echo -e ".env.local\n.env" >> .gitignore

echo "[7/9] check-env.ts"
mkdir -p scripts
cat > scripts/check-env.ts <<'EOF'
import { z } from "zod";
const Env = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(20),
  ANTHROPIC_API_KEY: z.string().startsWith("sk-ant-"),
  WHATSAPP_ACCESS_TOKEN: z.string().min(20),
  WHATSAPP_PHONE_NUMBER_ID: z.string().min(10),
  WHATSAPP_VERIFY_TOKEN: z.string().min(10),
  WHATSAPP_APP_SECRET: z.string().min(10),
});
const parsed = Env.safeParse(process.env);
if (!parsed.success) {
  console.error("❌ ENV VALIDATION FAILED:\n", parsed.error.flatten().fieldErrors);
  process.exit(1);
}
console.log("✅ Env validated");
EOF

echo "[8/9] WhatsApp-specific directories"
mkdir -p src/app/api/whatsapp/{webhook,send,flows} src/lib/{whatsapp,observability} evals templates
touch src/lib/whatsapp/{client.ts,signature.ts,templates.ts,quality-monitor.ts} evals/injection_results.md

echo "[9/9] First commit"
git init -q && git add -A && git commit -q -m "chore: scaffold WhatsApp bot (${TENANCY}-tenant) from Agency Kit WhatsApp for ${CLIENT_NAME}"

echo ""
echo "✅ WhatsApp bot project ready at: $TARGET_DIR"
echo "Tenancy: $TENANCY"
echo ""
echo "NEXT STEPS:"
echo "  1. cd $TARGET_DIR"
echo "  2. Set up WhatsApp Cloud API access (Meta Business Manager → WABA → phone number → tokens)"
echo "  3. Fill .env.local with real values"
echo "  4. Configure webhook URL in Meta console → /api/whatsapp/webhook"
echo "  5. Open in Claude Code — CLAUDE.md + progress.md load automatically"
echo "  6. Run the build prompt generator (File 42 + 42b addendum) to produce the full spec"
