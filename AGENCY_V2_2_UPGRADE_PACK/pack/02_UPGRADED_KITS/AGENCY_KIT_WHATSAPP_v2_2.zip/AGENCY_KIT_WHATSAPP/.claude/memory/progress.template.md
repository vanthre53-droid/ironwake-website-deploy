# PROGRESS — <client name> WhatsApp bot

**Status:** <scaffolded | building | gate-X-passed | deployed | maintenance>
**Tenancy:** <single | multi>
**WABA phone number:** <+91XXXXXXXXXX>
**Last updated:** <YYYY-MM-DD HH:MM UTC>

---

## Gate progress (WhatsApp-specific)
- [ ] Gate A — DB schema (contacts, conversations, messages, templates, flows, opt_ins, quality_rating_history, +tenants if multi)
- [ ] Gate B — Webhook + send routes (signature verified, idempotent, rate-limited)
- [ ] Gate C — Admin UI (conversations, templates, quality dashboard, broadcasts)
- [ ] Gate D — Security (5 injection tests, WABA token hygiene, RLS proven, opt-in audit)
- [ ] Gate E — Deploy + Sentry/Langfuse live
- [ ] **Gate F — Template approval** (Day-1 niche templates submitted with correct categories)
- [ ] **Gate G — Quality rating monitoring** (webhook subscribed, polling cron live, alerts wired, runbook in place)
- [ ] **Gate H — Flows encryption** (if Flows used — keys configured, decryption tested, submission flow E2E)

---

## ✅ Completed
- [x] <step>

## 🟡 In progress
- [ ] <current>

## 🔜 Up next
- [ ] <step>

## ⛔ Blockers
- <description>

## 💬 WhatsApp-specific metrics tracked
- Quality rating (current): <GREEN | YELLOW | RED>
- Messaging limit tier: <1K | 10K | 100K | UNLIMITED>
- Daily conversation volume (last 24h): <count>
- Cache hit rate: <%>
- Conversation QA average score (last 24h): <0-100>
- Compliance score (last 24h): <0-100>
- Average reply rate per template (last 7d): <%>

## 📋 Active templates (last status check: <date>)
| Name | Category | Status | Last reply rate |
|------|----------|--------|-----------------|
| <name> | <utility|marketing|auth> | <approved|pending|rejected|paused> | <%> |

## 🔄 Active Flows
| Name | Category | Endpoint | Last submission |
|------|----------|----------|-----------------|
| <name> | <APPOINTMENT_BOOKING|SIGN_UP|...> | <path> | <timestamp> |

## 📜 Decisions log
- <YYYY-MM-DD> — <decision> — <why>

## 🚧 Open questions for the user
- <question>

## 🔁 Reversions
- <YYYY-MM-DD> — <what didn't work> — <why> — <what we did instead>
