# SKILL: template_submission

**When to use:** Submitting WhatsApp message templates to Meta for approval. Day 1 — submit the niche template library (Section 28 of v2.1) before anything else, because approval takes 24–72 hours and you can't message outside the 24h window until they're approved.

**The three categories (get this right at submission — wrong category = rejection or quality drop):**

| Category | Use for | Cost (June 2026) | Examples |
|----------|---------|------------------|----------|
| **Utility** | Transactional, confirms an action the user expects | Lower per-message rate | Booking confirmation, payment receipt, delivery update, account alert |
| **Authentication** | OTP and verification codes | Lowest rate (OTP-only) | "Your OTP is {{1}}" |
| **Marketing** | Promotional, anything the user didn't directly trigger | Highest rate; requires opt-in | Seasonal offer, new product, "we miss you" |

**The rules for each category:**

### Utility
- Tied to a specific recent user action or scheduled service event
- No promotional language ("save 20%", "limited time", "buy now")
- Must be the actual transactional update (don't sneak marketing into utility templates)
- Examples that PASS: "Your appointment with Dr Sharma is confirmed for tomorrow at 3pm."
- Examples that FAIL: "Your appointment is confirmed! By the way, we now offer teeth whitening at a special price!"

### Authentication
- ONLY for OTPs, verification codes, account-security codes
- Buttons disabled by default (you can enable a "Copy code" button)
- Must have a code variable
- Examples that PASS: "Your verification code is {{1}}. Don't share this code."

### Marketing
- Anything promotional, including soft re-engagement
- Sent only to users with explicit WhatsApp marketing opt-in
- Examples: "Monsoon offer: 20% off cleaning until 30 June. Reply BOOK to schedule."

## Submission via API

```typescript
async function submitTemplate(template: {
  name: string;
  category: "UTILITY" | "AUTHENTICATION" | "MARKETING";
  language: string;  // "en_US", "hi_IN", "te_IN", etc.
  components: Array<HeaderComponent | BodyComponent | FooterComponent | ButtonsComponent>;
}) {
  const res = await fetch(
    `https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION}/${process.env.WHATSAPP_BUSINESS_ACCOUNT_ID}/message_templates`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(template)
    }
  );
  if (!res.ok) throw new Error(`Submission failed: ${await res.text()}`);
  return res.json();
}
```

**Example: appointment confirmation (utility)**
```json
{
  "name": "appointment_confirmation",
  "category": "UTILITY",
  "language": "en_US",
  "components": [
    {
      "type": "BODY",
      "text": "Hi {{1}}, your appointment with {{2}} is confirmed for {{3}}. Reply CANCEL to cancel.",
      "example": {
        "body_text": [["Aman", "Dr Sharma", "Tomorrow at 3pm"]]
      }
    },
    {
      "type": "BUTTONS",
      "buttons": [
        { "type": "QUICK_REPLY", "text": "Confirm" },
        { "type": "QUICK_REPLY", "text": "Reschedule" },
        { "type": "QUICK_REPLY", "text": "Cancel" }
      ]
    }
  ]
}
```

**Example: monsoon offer (marketing)**
```json
{
  "name": "monsoon_offer_v1",
  "category": "MARKETING",
  "language": "en_US",
  "components": [
    {
      "type": "HEADER",
      "format": "IMAGE",
      "example": { "header_handle": ["<uploaded-media-handle>"] }
    },
    {
      "type": "BODY",
      "text": "Hi {{1}}, save 20% on full cleaning this monsoon. Valid until {{2}}.",
      "example": { "body_text": [["Aman", "30 June"]] }
    },
    {
      "type": "FOOTER",
      "text": "Reply STOP to unsubscribe"
    },
    {
      "type": "BUTTONS",
      "buttons": [
        { "type": "QUICK_REPLY", "text": "Book now" },
        { "type": "QUICK_REPLY", "text": "Tell me more" }
      ]
    }
  ]
}
```

## Tracking template status

Subscribe to `message_template_status_update` webhook. When status changes, update your `templates` table:
- `PENDING` → just submitted, waiting
- `APPROVED` → ready to send
- `REJECTED` → reason in webhook payload; fix + resubmit (you cannot edit a rejected template; create a new one with a new name)
- `PAUSED` — Meta paused due to quality issues; revisit content + audience

## Common rejection reasons + fixes

| Reason | Fix |
|--------|-----|
| "Marketing content in utility template" | Re-submit as MARKETING category, or rewrite to be purely transactional |
| "Doesn't match category" | Recheck category mapping; rewrite content to match |
| "Promotional content in authentication" | Auth must be code-only |
| "Generic / spam content" | Personalize: add variables, be specific, avoid all-caps and excessive emoji |
| "Sample values missing" | Provide concrete example values for every variable |
| "Buttons configuration invalid" | Max 3 quick-reply OR max 2 CTA — never both, never >3 |
| "Header media type inconsistent" | Set ONE media type per template (image-header template can never accept video at send time) |

**Evidence (Gate F):**
- All Day-1 niche templates submitted (paste API response showing template IDs + status)
- Approval status tracked in `templates` table (snapshot showing approved templates)
- Rejected templates: rejection reason captured + corrective resubmission documented
- One sample message sent successfully for each approved template (paste API response with wamid)

**Done condition:** Day-1 templates approved (typically 24–72hr); resubmissions tracked; samples sent successfully.

**Speed tips:**
- Submit ALL Day-1 templates on Day 1 — they queue independently; you save days
- Use sample values that look real (not "test test test") — Meta reviewers approve faster
- Submit in the user's primary language first; translations can come later
- If migrating from another BSP/account: don't expect templates to carry over; resubmit
