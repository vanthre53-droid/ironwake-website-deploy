# SKILL: waba_setup

**When to use:** First-time configuration of a WhatsApp Business Account (WABA) for a client. Day 0–1 of the project.

**Decisions to make first:**

1. **Direct WhatsApp Cloud API vs BSP (Business Solution Provider)?**
   - **Direct (Cloud API)** — you manage the WABA + tokens. Lower cost, more control, more setup work. Best for: technical agencies, multi-client managed via your own infra.
   - **BSP** (360dialog, Gupshup, Wati, MessageBird, Twilio) — they manage the layer between you and Meta. Higher cost, faster setup, easier compliance support. Best for: agencies that want managed messaging without dealing with Meta directly.
   - **Recommendation for a solo/small agency:** Start direct on Cloud API. The cost difference at small volume is small; the learning is valuable.

2. **Phone number — new or migrated?**
   - New number: clean reputation, takes ~30 days to reach higher tiers
   - Migrate existing business number: requires owner's deactivation of regular WhatsApp first; reputation carries
   - Indian SMB: usually wants to migrate their existing business number (customers already know it)

3. **Display name** — must match the legal business or registered trade name; Meta verifies

**Setup steps (direct Cloud API):**

1. **Meta Business Manager** — create or use the client's existing one (the client owns this, not you)
2. **WhatsApp Business Account (WABA)** — create within Business Manager
3. **Phone number registration:**
   - Add phone number in WABA settings
   - Verify via SMS or voice OTP
   - Choose display name (Meta will review; typically 1-3 business days)
4. **Generate system user access token** (NOT a regular user token — those expire):
   - Business Manager → Settings → Users → System Users → Create
   - Assign to the WABA
   - Generate token with `whatsapp_business_messaging` + `whatsapp_business_management` scopes
   - Token never expires (until you rotate it manually)
5. **Configure webhook:**
   - Meta App Dashboard → WhatsApp → Configuration
   - Callback URL: `https://<your-app>/api/whatsapp/webhook`
   - Verify Token: a long random string you generate; store in `WHATSAPP_VERIFY_TOKEN`
   - Subscribe to fields: `messages`, `message_template_status_update`, `phone_number_quality_update`, `account_alerts`
6. **App secret** — Meta App Dashboard → App settings → Basic → App Secret. Store in `WHATSAPP_APP_SECRET`. This is what signs webhook payloads.

**Webhook verification code (the GET handshake Meta does once):**
```typescript
// GET /api/whatsapp/webhook
export async function GET(req: Request) {
  const url = new URL(req.url);
  const mode = url.searchParams.get("hub.mode");
  const token = url.searchParams.get("hub.verify_token");
  const challenge = url.searchParams.get("hub.challenge");
  
  if (mode === "subscribe" && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    return new Response(challenge, { status: 200 });
  }
  return new Response("Forbidden", { status: 403 });
}
```

**Inbound webhook signature verification (every POST):**
```typescript
// POST /api/whatsapp/webhook
import crypto from "crypto";

export async function POST(req: Request) {
  const signature = req.headers.get("x-hub-signature-256");
  const rawBody = await req.text();
  
  const expected = "sha256=" + crypto
    .createHmac("sha256", process.env.WHATSAPP_APP_SECRET!)
    .update(rawBody)
    .digest("hex");
  
  if (!signature || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
    return new Response("Invalid signature", { status: 401 });
  }
  
  const payload = JSON.parse(rawBody);
  // ... process payload
}
```

**Send a test message:**
```typescript
async function sendText(to: string, body: string) {
  const res = await fetch(
    `https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION}/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type: "text",
        text: { body }
      })
    }
  );
  if (!res.ok) throw new Error(`Send failed: ${await res.text()}`);
  return res.json();
}
```

**Evidence:**
- Webhook GET verification: Meta dashboard shows callback URL "Verified ✓"
- Test inbound: send a WhatsApp message to the number from your phone → webhook receives, signature verifies (paste log)
- Test outbound: send a text message via your code → recipient's WhatsApp receives it (paste API response with wamid)
- All env vars set + verified by `pnpm check-env`

**Done condition:** Webhook verified, signed inbound works, outbound send works, tokens stored securely.

**Common mistakes:**
- Using a regular user access token (expires) instead of system user token (doesn't)
- Forgetting to subscribe to `phone_number_quality_update` field — quality monitoring won't work
- Webhook signature verification disabled "for testing" then forgotten — security hole shipped
- WABA token in `NEXT_PUBLIC_*` — token exposed to client; account hijack risk
- Display name doesn't match registered business name — Meta rejects + delays go-live
