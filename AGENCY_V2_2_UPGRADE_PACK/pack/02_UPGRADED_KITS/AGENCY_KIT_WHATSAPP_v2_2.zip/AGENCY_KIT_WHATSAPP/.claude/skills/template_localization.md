# SKILL: template_localization

**When to use:** Any IN client (and ES for many US niches). Meta approves templates PER LANGUAGE. Sales-blocker W4 for Indian SMB.

**Reference:** WhatsApp v2.2 Section 36 (modules/42c-WHATSAPP_v2_2_CONSOLIDATED.md).

**Steps:**
1. Structure: `templates/<niche>/<template_name>.<lang>.json` — each language its own Meta submission, own approval, own category.
2. Priorities: IN = EN + HI always, Telugu/Tamil/Kannada/Bengali by region (Nellore/AP → Telugu matters) · US = EN + ES · UK/CA/AU = EN with spelling/tone localized.
3. Hygiene: same category across languages · `{{1}} {{2}}` map to the SAME data everywhere · native-quality translation (clumsy Hindi reads as spam → quality downgrade) · sample values per language.

**Evidence:** per-language approval statuses pasted; category identical across variants.
