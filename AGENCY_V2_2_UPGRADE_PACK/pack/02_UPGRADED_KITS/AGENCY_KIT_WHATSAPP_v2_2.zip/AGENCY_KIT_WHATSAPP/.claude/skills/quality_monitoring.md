# SKILL: quality_monitoring

**When to use:** Every WhatsApp project, mandatory before Gate G. Wire it up Day 1 — by the time you "need" it, it's too late.

**Reference:** WhatsApp v2.1 Section 23 + `rules/QUALITY_RATING_PLAYBOOK.md`.

## Steps

### 1. Create the history table
```sql
CREATE TABLE quality_rating_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_number_id TEXT NOT NULL,
  rating TEXT NOT NULL CHECK (rating IN ('GREEN', 'YELLOW', 'RED', 'UNKNOWN')),
  messaging_limit_tier TEXT NOT NULL,
  checked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  source TEXT NOT NULL  -- 'webhook' / 'polling' / 'manual'
);
CREATE INDEX idx_quality_phone_time ON quality_rating_history(phone_number_id, checked_at DESC);
```

### 2. Subscribe to the webhook (during waba_setup)
- Meta App Dashboard → WhatsApp → Configuration → Webhook fields → enable `phone_number_quality_update`
- Already subscribed if you followed the waba_setup skill correctly

### 3. Handle the webhook event
In your `/api/whatsapp/webhook` handler:
```typescript
if (entry.changes[0].field === "phone_number_quality_update") {
  const { phone_number_id, quality_rating } = entry.changes[0].value;
  await db.qualityRatingHistory.create({
    data: {
      phoneNumberId: phone_number_id,
      rating: quality_rating,
      messagingLimitTier: await getMessagingLimitTier(phone_number_id),  // fetch separately
      source: "webhook"
    }
  });
  await onQualityChange(phone_number_id, quality_rating);
}
```

### 4. Build the polling cron (backup; some accounts don't get webhook events reliably)
Cron every 6 hours:
```typescript
export async function pollQualityRatings() {
  const phoneNumberIds = await db.tenants.findMany({ select: { wabaPhoneNumberId: true }});  // or just env for single-tenant
  
  for (const { wabaPhoneNumberId } of phoneNumberIds) {
    const res = await fetch(
      `https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION}/${wabaPhoneNumberId}?fields=quality_rating,messaging_limit_tier`,
      { headers: { Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}` }}
    );
    const { quality_rating, messaging_limit_tier } = await res.json();
    
    const lastReading = await db.qualityRatingHistory.findFirst({
      where: { phoneNumberId: wabaPhoneNumberId }, orderBy: { checkedAt: "desc" }
    });
    
    // Only insert if rating changed (avoid storing duplicate rows)
    if (!lastReading || lastReading.rating !== quality_rating || lastReading.messagingLimitTier !== messaging_limit_tier) {
      await db.qualityRatingHistory.create({
        data: { phoneNumberId: wabaPhoneNumberId, rating: quality_rating, messagingLimitTier: messaging_limit_tier, source: "polling" }
      });
      
      if (!lastReading || lastReading.rating !== quality_rating) {
        await onQualityChange(wabaPhoneNumberId, quality_rating, lastReading?.rating);
      }
    }
  }
}
```

Schedule via Vercel Cron: `*/360 * * * *` (every 6 hours).

### 5. Wire the alerts
```typescript
async function onQualityChange(phoneNumberId: string, newRating: string, oldRating?: string) {
  const tenant = await db.tenants.findFirst({ where: { wabaPhoneNumberId: phoneNumberId }});
  
  switch (newRating) {
    case "YELLOW":
      // Freeze marketing template sends; keep utility + auth flowing
      await freezeMarketingSends(tenant.id);
      await sendAlert({ tenant, level: "P1", subject: "WhatsApp quality rating dropped to YELLOW", body: yellowEmailBody(tenant, oldRating) });
      await dashboardBanner(tenant.id, "WARNING: Quality rating YELLOW. Marketing sends paused. See runbook.");
      break;
      
    case "RED":
      // Freeze ALL template sends; only 24h-window conversations continue
      await freezeAllTemplateSends(tenant.id);
      await sendAlert({ tenant, level: "P0", subject: "🚨 WhatsApp quality rating RED — IMMEDIATE ACTION", body: redEmailBody(tenant, oldRating) });
      await dashboardBanner(tenant.id, "CRITICAL: Quality rating RED. All template sends paused. Recovery playbook required.");
      break;
      
    case "GREEN":
      if (oldRating === "YELLOW" || oldRating === "RED") {
        // Recovered — but don't auto-unfreeze; require human to confirm root cause was fixed
        await sendAlert({ tenant, level: "INFO", subject: "Quality rating recovered to GREEN — confirm before unfreezing sends", body: recoveryEmailBody(tenant) });
      }
      break;
  }
}
```

### 6. Admin dashboard
`/admin/whatsapp/quality`:
- Current rating + messaging limit tier (color-coded indicator)
- 30-day rating timeline (line chart)
- Recent template sends (last 7d) with reply rate per template — flag templates with low reply rate as risk
- Send velocity chart (messages/hour over time)
- Block/report event counts (if available in account_alerts webhook)

### 7. Runbook reference
Link `docs/RUNBOOKS.md` to `rules/QUALITY_RATING_PLAYBOOK.md` so the recovery procedure is one click away when the alert fires.

### 8. Test the alerting end-to-end
Trigger a simulated quality change in dev:
- Mock webhook event with rating=YELLOW
- Verify: marketing freeze fires, email arrives, dashboard banner shows
- Repeat for RED
- Document the test in `evals/quality_monitoring_test.md`

**Evidence (Gate G):**
- `quality_rating_history` populated with last 24h of readings (webhook + polling both producing entries)
- Current rating at deploy time = GREEN
- Simulated YELLOW alert tested end-to-end (paste email + dashboard screenshot)
- Simulated RED alert tested
- Runbook present in `docs/RUNBOOKS.md`

**Done condition:** Monitoring active, alerts wired, simulation passed, runbook documented.

**What gets missed without this:**
- Quality drops silently → marketing volume tanks invisibly for days
- Client notices their reach is half what it was — by then it's already RED
- Recovery from RED takes weeks; from YELLOW caught early, hours
- Difference between "good agency" and "great agency" is whether you saw the drop in real time
