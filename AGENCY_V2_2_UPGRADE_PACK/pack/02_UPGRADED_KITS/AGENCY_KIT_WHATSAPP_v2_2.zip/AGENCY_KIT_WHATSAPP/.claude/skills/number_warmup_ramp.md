# SKILL: number_warmup_ramp

**When to use:** Every NEW WABA number before any volume. A fresh number blasting sends tanks to RED before it earns tier. Sales-blocker W3.

**Reference:** WhatsApp v2.2 Section 35 (modules/42c-WHATSAPP_v2_2_CONSOLIDATED.md).

**Steps:**
1. Ramp business-initiated conversations/day, each step gated on quality staying GREEN: days 1–2: 50 · 3–4: 100 · 5–7: 250 · 8–14: 500→1K · 15+: Meta tier.
2. YELLOW mid-ramp → FREEZE at current level, run the §23C root-cause checklist, resume only after GREEN 48h.
3. Prioritize inbound-triggered service conversations during ramp (don't count against initiation limits; build reply-rate signal).
4. Persist as `number_warmup` state on `tenants`; the send scheduler reads it.

**Evidence:** ramp state advances only on GREEN; a simulated YELLOW freezes it. Paste the state rows.
