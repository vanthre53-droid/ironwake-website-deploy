# SKILL: multi_tenant_routing

**When to use:** Agency manages >3 client WABA numbers from one codebase. Skip if single-client.

**Reference:** WhatsApp v2.1 Section 24.

## Decision: when to actually do this
- 1 client → single-tenant; this skill is overkill
- 2-3 clients → still single-tenant per client (independent instances); complexity not yet justified
- 4+ clients → multi-tenant; this skill is required

## Architecture overview
- One codebase, one Vercel deploy
- One webhook endpoint receives messages for ALL tenants
- Routing key: `phone_number_id` in the inbound payload → look up tenant → load tenant's tokens + system prompt
- Per-tenant DB isolation via RLS

## Steps

### 1. Add `tenants` table + `tenant_id` to all business tables
```sql
CREATE TABLE tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  waba_phone_number_id TEXT NOT NULL UNIQUE,
  waba_business_account_id TEXT NOT NULL,
  display_phone_number TEXT NOT NULL,
  webhook_verify_token TEXT NOT NULL UNIQUE,
  access_token_secret_ref TEXT NOT NULL,  -- e.g. "infisical://prod/tenants/sunrise-dental/waba-token"
  system_prompt_ref TEXT,                  -- per-tenant prompt customization
  monthly_message_quota INTEGER,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Migrate existing tables
ALTER TABLE contacts ADD COLUMN tenant_id UUID REFERENCES tenants(id);
ALTER TABLE conversations ADD COLUMN tenant_id UUID REFERENCES tenants(id);
ALTER TABLE messages ADD COLUMN tenant_id UUID REFERENCES tenants(id);
ALTER TABLE templates ADD COLUMN tenant_id UUID REFERENCES tenants(id);
ALTER TABLE whatsapp_flows ADD COLUMN tenant_id UUID REFERENCES tenants(id);
ALTER TABLE opt_ins ADD COLUMN tenant_id UUID REFERENCES tenants(id);
-- ... every business table

-- Indexes
CREATE INDEX idx_contacts_tenant ON contacts(tenant_id, phone);
CREATE INDEX idx_messages_tenant_conv ON messages(tenant_id, conversation_id, created_at);
CREATE INDEX idx_templates_tenant_status ON templates(tenant_id, status);
```

Make `tenant_id` `NOT NULL` after backfill.

### 2. RLS on every tenant table
```sql
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_select ON contacts FOR SELECT TO authenticated
  USING (tenant_id = (auth.jwt() ->> 'tenant_id')::uuid);
CREATE POLICY tenant_isolation_insert ON contacts FOR INSERT TO authenticated
  WITH CHECK (tenant_id = (auth.jwt() ->> 'tenant_id')::uuid);
CREATE POLICY tenant_isolation_update ON contacts FOR UPDATE TO authenticated
  USING (tenant_id = (auth.jwt() ->> 'tenant_id')::uuid)
  WITH CHECK (tenant_id = (auth.jwt() ->> 'tenant_id')::uuid);
-- Repeat for every tenant-scoped table

-- Agency admin role can see across tenants
CREATE POLICY agency_admin_all_access ON contacts FOR ALL TO authenticated
  USING ((auth.jwt() ->> 'role') = 'agency_admin');
```

Run `tenant_isolation_test` skill from V7 Kit to prove isolation.

### 3. Webhook routing
```typescript
// /api/whatsapp/webhook/route.ts
export async function POST(req: Request) {
  const rawBody = await req.text();
  const signature = req.headers.get("x-hub-signature-256");
  
  // Verify with the APP SECRET (one app, all tenants share)
  if (!verifySignature(rawBody, signature, process.env.WHATSAPP_APP_SECRET!)) {
    return new Response("Invalid signature", { status: 401 });
  }
  
  const payload = JSON.parse(rawBody);
  
  for (const entry of payload.entry) {
    for (const change of entry.changes) {
      const phoneNumberId = change.value.metadata?.phone_number_id;
      if (!phoneNumberId) continue;
      
      // Route to tenant
      const tenant = await db.tenants.findUnique({ where: { wabaPhoneNumberId: phoneNumberId }});
      if (!tenant) {
        await logSecurityEvent({ event: "webhook_unknown_tenant", phoneNumberId });
        continue;  // ignore — could be a misconfigured webhook from another account
      }
      if (!tenant.active) continue;
      
      // Load tenant token from Infisical
      const tenantToken = await infisical.getSecret(tenant.accessTokenSecretRef);
      
      // Process scoped to this tenant
      await processInbound(change, { tenantId: tenant.id, accessToken: tenantToken });
    }
  }
  
  return new Response("OK", { status: 200 });
}
```

### 4. Per-tenant token loading
```typescript
// src/lib/whatsapp/client.ts
export async function sendForTenant(tenantId: string, to: string, message: object) {
  const tenant = await db.tenants.findUnique({ where: { id: tenantId }});
  const token = await infisical.getSecret(tenant.accessTokenSecretRef);
  
  return fetch(
    `https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION}/${tenant.wabaPhoneNumberId}/messages`,
    { method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }, body: JSON.stringify({ messaging_product: "whatsapp", to, ...message })}
  );
}
```

### 5. Per-tenant billing
```sql
CREATE TABLE tenant_billing (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id),
  period TEXT NOT NULL,   -- '2026-06'
  messages_utility INTEGER NOT NULL DEFAULT 0,
  messages_marketing INTEGER NOT NULL DEFAULT 0,
  messages_authentication INTEGER NOT NULL DEFAULT 0,
  messages_service INTEGER NOT NULL DEFAULT 0,
  ai_tokens_input BIGINT NOT NULL DEFAULT 0,
  ai_tokens_output BIGINT NOT NULL DEFAULT 0,
  total_cost_cents INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, period)
);
```

Monthly cron aggregates → generate PDF invoice → email to client.

### 6. Admin UI multi-tenant updates
- **Top-bar tenant switcher** for agency_admin users only
- Client_admin users: scoped to their tenant by JWT claim
- New view: `/admin/agency` — cross-tenant analytics (revenue per tenant, message volume, quality rating per tenant)
- Per-tenant quality dashboard at `/admin/[tenantSlug]/quality`

### 7. Onboarding new tenants (the agency-scale moment)
A `/admin/agency/tenants/new` form captures:
- Tenant name + slug
- WABA phone number ID + WABA business account ID
- WABA access token (you store in Infisical via the admin form; the token never sits in your DB)
- Display phone number
- Monthly quota for billing

After creation, give the client a tenant_id-scoped login URL and they're operational.

**Evidence:**
- Schema migration applied
- RLS proven via cross-tenant test (use `tenant_isolation_test` skill from V7 Kit)
- Webhook routing tested: simulated webhook for tenant A doesn't touch tenant B's data
- 2+ test tenants set up; messages sent to/from each work independently
- Per-tenant billing roll-up cron runs successfully

**Done condition:** Two real tenants operate independently on one deploy with no data crossover.

**Anti-patterns:**
- Forgetting to scope tenant_id on a query → returns mixed-tenant data → catastrophic privacy bug
- Storing tenant tokens in the DB column directly (not Infisical) → token theft via DB compromise
- Using service-role Supabase client server-side without manually scoping queries by tenant → bypasses RLS entirely
- Mixing agency-admin role with client-admin without JWT role check → clients see other clients' data
- Single webhook URL pointing to multiple Meta apps — confusing, fragile; use ONE Meta app for all tenants
