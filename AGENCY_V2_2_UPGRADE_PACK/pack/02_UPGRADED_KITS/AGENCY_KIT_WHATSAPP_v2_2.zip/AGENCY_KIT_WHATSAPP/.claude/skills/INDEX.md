# SKILLS INDEX — Agency Kit WhatsApp

| # | Skill | When |
|---|-------|------|
| 1 | `waba_setup` | First-time WABA configuration — phone number, webhook, BSP vs direct |
| 2 | `template_submission` | Submit templates correctly so they approve fast + stay approved |
| 3 | `flows_design` | Build WhatsApp Flows for structured input (Section 22 of v2.1) — biggest UX upgrade vs v2.0 |
| 4 | `ctwa_attribution_setup` | Click-to-WhatsApp Ads + Conversions API attribution (Section 27 of v2.1) |
| 5 | `quality_monitoring` | Wire quality rating webhook + polling + alerting (Section 23 of v2.1) |
| 6 | `multi_tenant_routing` | Multi-WABA architecture for agency-managed clients (Section 24 of v2.1) |
| 7 | `payments_integration_upi` | WhatsApp Pay UPI integration for Indian SMBs (Section 25 of v2.1) |
| 8 | `conversation_analytics_setup` | Auto-CSAT + intent extraction + weekly digest (Section 29 of v2.1) |

Every skill ends in evidence: webhook test result, signature verification proof, template approval IDs, Flow submission payload, quality rating reading, attribution events.

## v2.2 additions
| 9 | `stop_optout_setup` | Global STOP/START suppression, per-language, checked on every send (§34) — ship-blocker |
| 10 | `number_warmup_ramp` | New-number volume ramp gated on GREEN quality (§35) |
| 11 | `template_localization` | Per-language template library + submission hygiene, Hindi/Telugu first (§36) |
