# SKILL: payments_integration_upi

**When to use:** WhatsApp Pay UPI integration for Indian SMBs. Skip if non-India market (other markets are in pilot — verify before promising).

**Reference:** WhatsApp v2.1 Section 25.

## What WhatsApp Pay (India) is
- In-chat payment via UPI
- User taps "Pay" button → opens native UPI flow inside WhatsApp → selects UPI app → completes
- Settles to client's bank account via the merchant of record (the client, not you)
- Mature since 2020; growing volume in 2026

## Pre-conditions (before any code)
- Client has a registered Indian business (Sole Prop / LLP / Pvt Ltd) with PAN + GST
- Client has signed up for WhatsApp Pay merchant account via Meta Business Manager → Payments
- Client's bank account verified for UPI settlement
- KYC complete (NPCI requirements; Meta handles via the WABA merchant flow)
- You (agency) are NOT the merchant of record. The client is. Your role is technical integration.

## Architecture

```
User taps "Book + Pay" button in your bot's message
  → Your code sends a payment_request interactive message
  → WhatsApp shows the payment UI natively
  → User taps "Pay" → UPI app selector → completes payment
  → Meta webhook fires: payment_status webhook
  → Your code updates `payments.status` → triggers downstream (booking confirmed, receipt sent)
```

## Steps

### 1. Table
```sql
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES tenants(id),
  contact_id UUID NOT NULL REFERENCES contacts(id),
  reference_id TEXT NOT NULL UNIQUE,  -- your internal reference
  amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'INR',
  status TEXT NOT NULL CHECK (status IN ('initiated', 'pending', 'success', 'failed', 'expired', 'refunded')),
  provider_payment_id TEXT,           -- Meta's transaction ID after success
  related_order_id UUID,
  initiated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);
CREATE INDEX idx_payments_contact_status ON payments(contact_id, status);
CREATE INDEX idx_payments_reference ON payments(reference_id);
```

### 2. Send payment request
```typescript
async function requestPayment(args: {
  to: string;
  contactId: string;
  amountMinor: number;
  description: string;
  relatedOrderId?: string;
}) {
  const referenceId = `pay_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;
  
  await db.payments.create({
    data: {
      contactId: args.contactId,
      referenceId,
      amountMinor: args.amountMinor,
      currency: "INR",
      status: "initiated",
      relatedOrderId: args.relatedOrderId
    }
  });
  
  // Send the payment request message
  await fetch(`https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION}/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: args.to,
        type: "interactive",
        interactive: {
          type: "order_details",
          // ... order_details schema with line items + total
          // Meta's payment schema is detailed; refer to official docs for the exact body
          // Note: exact JSON shape evolves; check WhatsApp Business Platform docs
          payment_settings: {
            type: "payment_gateway",
            payment_gateway: {
              type: "upi",
              configuration: { reference_id: referenceId, /* ... */ }
            }
          }
        }
      })
    });
}
```

(The Meta payment payload schema is detailed and version-specific. Refer to https://developers.facebook.com/docs/whatsapp/business-platform/payments for the current spec; the above is illustrative.)

### 3. Webhook handler — `payment_status` event
```typescript
if (entry.changes[0].field === "messages") {
  const value = entry.changes[0].value;
  if (value.statuses) {
    for (const status of value.statuses) {
      if (status.type === "payment") {
        await handlePaymentUpdate(status);
      }
    }
  }
}

async function handlePaymentUpdate(status: any) {
  const referenceId = status.payment_reference_id;
  const payment = await db.payments.findUnique({ where: { referenceId }});
  if (!payment) {
    await logSecurityEvent({ event: "payment_webhook_unknown_reference", referenceId });
    return;
  }
  
  // Idempotency: don't regress states (success cannot become pending)
  const validTransitions = {
    "initiated": ["pending", "success", "failed", "expired"],
    "pending": ["success", "failed", "expired"],
    "success": ["refunded"],
    "failed": [],
    "expired": [],
    "refunded": []
  };
  
  if (!validTransitions[payment.status]?.includes(status.payment_status)) {
    console.warn(`Invalid transition ${payment.status} -> ${status.payment_status} for ${referenceId}`);
    return;
  }
  
  await db.payments.update({
    where: { referenceId },
    data: {
      status: status.payment_status,
      providerPaymentId: status.provider_payment_id,
      completedAt: ["success", "failed", "expired"].includes(status.payment_status) ? new Date() : null
    }
  });
  
  // Downstream
  if (status.payment_status === "success") {
    await onPaymentSuccess(payment);  // confirm booking, send receipt template, update order
  } else if (status.payment_status === "failed") {
    await onPaymentFailure(payment);  // notify user, suggest retry
  }
}
```

### 4. Refund flow (admin-initiated)
```typescript
async function initiateRefund(paymentId: string, reason: string, initiatedBy: string) {
  // Audit log + actual Meta API call to refund
  await db.auditLogs.create({
    data: { event: "refund_initiated", paymentId, reason, userId: initiatedBy }
  });
  
  const res = await fetch(/* Meta refund endpoint */);
  if (!res.ok) throw new Error("Refund failed");
  
  await db.payments.update({ where: { id: paymentId }, data: { status: "refunded" }});
}
```

### 5. Admin UI
`/admin/payments`:
- Table: all payments per tenant with status filter
- Click → detail with: order info, contact, status timeline, refund button (with reason field)
- Reconciliation view: payments table vs Meta's reported payouts (alert on mismatch)

**Evidence:**
- Schema applied
- Test payment end-to-end: payment_request sent → user paid via test UPI → webhook received → status=success → downstream (e.g. confirmation template) triggered
- Idempotency tested: same webhook delivered twice → only one state change
- Refund flow tested with a small test transaction
- One reconciliation cycle against Meta's payout report

**Done condition:** Real (test) payment flows end-to-end. Refund works. Reconciliation matches Meta.

**What gets you in trouble:**
- Treating the agency as the merchant of record → financial + tax + KYC mess. The CLIENT is the merchant; the agency is a technical service provider.
- Not handling idempotency → double-processed payments, double-confirmed bookings, angry users
- Storing UPI VPAs in your DB without good reason → privacy risk + not needed (Meta handles the payment flow)
- Skipping reconciliation → silent revenue leak from payment-success-but-app-didn't-notice cases
- Promising payments before the client's KYC is approved by Meta — KYC can take 1-3 weeks; build around it, don't gate everything on it
