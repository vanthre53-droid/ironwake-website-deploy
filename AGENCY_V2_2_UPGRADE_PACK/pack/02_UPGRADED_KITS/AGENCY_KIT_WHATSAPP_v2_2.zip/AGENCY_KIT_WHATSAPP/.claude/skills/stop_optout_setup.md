# SKILL: stop_optout_setup

**When to use:** EVERY WhatsApp build, single-client included. Regulatory must-have AND quality-rating protection. Ship-blocker W2.

**Reference:** WhatsApp v2.2 Section 34 (modules/42c-WHATSAPP_v2_2_CONSOLIDATED.md).

**Steps:**
1. Keywords per language, whole-message intent match (never substring — don't opt out "stop by tomorrow"): EN STOP/UNSUBSCRIBE/CANCEL/OPT OUT · HI बंद करो/रोको/हटाओ · TE ఆపు/వద్దు.
2. On STOP: write `suppression_list` (E.164, shared pattern with Voice §25) → halt ALL non-service messaging → send ONE confirmation ("Reply START to resume") → honor START. Log every transition.
3. EVERY marketing/utility send checks suppression pre-dispatch (mirror of canDial). Bypassing = P0.

**Evidence:** STOP → suppressed + confirmed; a subsequent template send to that contact BLOCKED. Paste both.
