# SKILL: flows_design

**When to use:** Building a WhatsApp Flow — Meta's native mini-app form inside WhatsApp. The biggest gap in v2.0; the biggest UX upgrade in v2.1.

**Reference:** WhatsApp v2.1 Section 22 — when to use Flows vs interactive messages, architecture, encryption.

## When to use a Flow (decision rule)
- ≥3 structured inputs in one task → Flow
- Native UI needed (date picker, dropdown >10 items, multi-select) → Flow
- Multi-step with conditional branching → Flow
- Otherwise → buttons/lists from v2.0

## Architecture summary
- Flow JSON spec uploaded to Meta
- User taps a button in your message → WhatsApp opens the Flow natively in-app
- Flow can make data_exchange calls to YOUR endpoint mid-flow (for dynamic content like available slots)
- On submit, Meta POSTs the encrypted payload to your endpoint
- You decrypt, process, respond with success/error, render any follow-up message

## Steps

### 1. Design the screens (use Meta's Flow Builder UI)
A Flow has 1-N screens. Each screen is a single form view. Plan the user journey:
- Screen 1: pick service (RadioButtonsGroup)
- Screen 2: pick date + slot (DatePicker + Dropdown — slots fetched dynamically)
- Screen 3: name + phone + notes (TextInput + TextArea)
- Screen 4: review + confirm (read-only summary + Footer with "Confirm" button)

### 2. Configure your data exchange endpoint

Generate a key pair for Flow encryption:
```bash
openssl genrsa -des3 -out flow_private_key.pem 2048
openssl rsa -in flow_private_key.pem -outform PEM -pubout -out flow_public_key.pem
```

Upload the public key to Meta (Business Manager → WhatsApp → Configuration → Flow public keys).
Store the private key in Infisical / env (`WHATSAPP_FLOWS_PRIVATE_KEY_PEM` + `WHATSAPP_FLOWS_PASSPHRASE`).

### 3. Build the Flow JSON (example: booking flow)
```json
{
  "version": "6.0",
  "data_api_version": "3.0",
  "routing_model": {
    "PICK_SERVICE": ["PICK_SLOT"],
    "PICK_SLOT": ["CONTACT_INFO"],
    "CONTACT_INFO": ["REVIEW"],
    "REVIEW": ["SUCCESS"]
  },
  "screens": [
    {
      "id": "PICK_SERVICE",
      "title": "Pick a service",
      "terminal": false,
      "data": {},
      "layout": {
        "type": "SingleColumnLayout",
        "children": [
          {
            "type": "RadioButtonsGroup",
            "name": "service_id",
            "label": "Select service",
            "data-source": [
              { "id": "cleaning", "title": "Cleaning ₹2200" },
              { "id": "rct", "title": "Root Canal ₹6500" }
            ],
            "required": true
          },
          {
            "type": "Footer",
            "label": "Next",
            "on-click-action": { "name": "navigate", "next": { "type": "screen", "name": "PICK_SLOT" }, "payload": { "service_id": "${form.service_id}" }}
          }
        ]
      }
    },
    {
      "id": "PICK_SLOT",
      "title": "Pick a time",
      "data": { "service_id": { "type": "string", "__example__": "cleaning" }, "slots": { "type": "array", "items": { "type": "object" }}},
      "layout": {
        "type": "SingleColumnLayout",
        "children": [
          {
            "type": "DatePicker",
            "name": "date",
            "label": "Date",
            "required": true,
            "min-date": "today",
            "max-date": "60_days_ahead"
          },
          {
            "type": "Dropdown",
            "name": "slot_id",
            "label": "Available slots",
            "data-source": "${data.slots}",
            "required": true
          },
          {
            "type": "Footer",
            "label": "Next",
            "on-click-action": { "name": "data_exchange", "payload": { "service_id": "${data.service_id}", "date": "${form.date}", "slot_id": "${form.slot_id}" }}
          }
        ]
      }
    }
    // ... CONTACT_INFO, REVIEW, SUCCESS screens
  ]
}
```

### 4. Upload the Flow to Meta
```typescript
async function uploadFlow(name: string, flowJson: object, category: string) {
  // First: create the Flow (metadata)
  const createRes = await fetch(
    `https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION}/${process.env.WHATSAPP_BUSINESS_ACCOUNT_ID}/flows`,
    { method: "POST", headers: { Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`, "Content-Type": "application/json" },
      body: JSON.stringify({ name, categories: [category], endpoint_uri: `${process.env.NEXT_PUBLIC_APP_URL}/api/whatsapp/flows/${name}` })}
  );
  const { id: flowId } = await createRes.json();
  
  // Then: upload the JSON
  const fd = new FormData();
  fd.set("file", new Blob([JSON.stringify(flowJson)], { type: "application/json" }), `${name}.json`);
  fd.set("asset_type", "FLOW_JSON");
  
  await fetch(`https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION}/${flowId}/assets`,
    { method: "POST", headers: { Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}` }, body: fd });
  
  // Then: publish (move from DRAFT → PUBLISHED)
  await fetch(`https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION}/${flowId}/publish`,
    { method: "POST", headers: { Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}` }});
  
  return flowId;
}
```

### 5. Build the data_exchange endpoint with decryption
```typescript
// /api/whatsapp/flows/[flowName]/route.ts
import crypto from "crypto";

export async function POST(req: Request, { params }: { params: { flowName: string }}) {
  const { encrypted_aes_key, encrypted_flow_data, initial_vector } = await req.json();
  
  // Decrypt AES key with our RSA private key
  const privateKey = crypto.createPrivateKey({
    key: process.env.WHATSAPP_FLOWS_PRIVATE_KEY_PEM!,
    passphrase: process.env.WHATSAPP_FLOWS_PASSPHRASE
  });
  
  const decryptedAesKey = crypto.privateDecrypt(
    { key: privateKey, padding: crypto.constants.RSA_PKCS1_OAEP_PADDING, oaepHash: "sha256" },
    Buffer.from(encrypted_aes_key, "base64")
  );
  
  // Decrypt flow data with AES key
  const iv = Buffer.from(initial_vector, "base64");
  const encryptedFlowDataBuffer = Buffer.from(encrypted_flow_data, "base64");
  const TAG_LENGTH = 16;
  const tag = encryptedFlowDataBuffer.subarray(-TAG_LENGTH);
  const ciphertext = encryptedFlowDataBuffer.subarray(0, -TAG_LENGTH);
  
  const decipher = crypto.createDecipheriv("aes-128-gcm", decryptedAesKey, iv);
  decipher.setAuthTag(tag);
  const decrypted = JSON.parse(Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString());
  
  // Process: { action: "INIT" | "data_exchange" | "ping", screen, data, flow_token, version }
  const responsePayload = await processFlowAction(decrypted, params.flowName);
  
  // Encrypt response (flip IV bits as per Meta spec)
  const flippedIv = Buffer.from(iv.map(b => ~b & 0xff));
  const cipher = crypto.createCipheriv("aes-128-gcm", decryptedAesKey, flippedIv);
  const encryptedResponse = Buffer.concat([cipher.update(JSON.stringify(responsePayload), "utf8"), cipher.final(), cipher.getAuthTag()]);
  
  return new Response(encryptedResponse.toString("base64"), { headers: { "Content-Type": "text/plain" }});
}
```

### 6. Handle Flow actions
Inside `processFlowAction`:
- `INIT` — return the initial data for the first screen (or load the requested screen's data)
- `data_exchange` — user moved to next screen needing dynamic data; return data for that next screen
- `BACK` — user went back; return state for the previous screen
- On final `data_exchange` with `flow_action: "complete"`: process submission, return `{ screen: "SUCCESS", data: { extension_message_response: {...} }}`

### 7. Send the Flow message to a user
```typescript
async function sendFlowMessage(to: string, flowId: string, flowName: string) {
  await fetch(`https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION}/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type: "interactive",
        interactive: {
          type: "flow",
          header: { type: "text", text: "Book your appointment" },
          body: { text: "Tap below to pick a time that works for you." },
          footer: { text: "Powered by [your business]" },
          action: {
            name: "flow",
            parameters: {
              flow_message_version: "3",
              flow_token: crypto.randomUUID(),  // unique per send; lets you correlate
              flow_id: flowId,
              flow_cta: "Book now",
              flow_action: "navigate",
              flow_action_payload: { screen: "PICK_SERVICE" }
            }
          }
        }
      })
    });
}
```

### 8. Fallback for unsupported clients
Some older WhatsApp versions can't render Flows. Detect from user profile capability; if unsupported, fall back to a sequence of interactive messages. Log `messages.metadata.flow_fallback_used = true`.

**Evidence (Gate H):**
- Flow uploaded + published successfully (paste flow_id + status)
- Public key uploaded to Meta; private key in Infisical
- Test flow sent to your phone → opens natively → submission goes through
- Decryption tested with tampered payload → rejected
- Submission outcome: row created in DB (e.g. appointment) + confirmation message sent

**Done condition:** A real user completes the Flow end-to-end and the result lands in your DB correctly.

**Anti-patterns:**
- Building a 10-screen Flow when 3 would do — drop-off rises with screen count
- Calling external APIs synchronously inside data_exchange without caching — Flow feels slow, users abandon
- Forgetting validation server-side — client-side Flow validation can be bypassed
- Not handling the BACK action — users get stuck
- Storing the Flow private key in `NEXT_PUBLIC_*` — game over (anyone can decrypt your Flow submissions)
