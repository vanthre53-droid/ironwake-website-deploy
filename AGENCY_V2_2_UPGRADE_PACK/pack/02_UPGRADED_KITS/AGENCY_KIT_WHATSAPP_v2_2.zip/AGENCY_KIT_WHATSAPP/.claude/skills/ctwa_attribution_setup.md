# SKILL: ctwa_attribution_setup

**When to use:** When the client runs Click-to-WhatsApp Ads (Meta Ads → opens WhatsApp directly). This is the discoverability lever for WhatsApp bots — NOT SEO. Without attribution, the client flies blind on ad ROAS.

**Reference:** WhatsApp v2.1 Section 27.

## What it is
- Facebook or Instagram ad with "Send Message" CTA
- Clicking opens the user's WhatsApp directly to a chat with the client's WABA number
- Pre-fills an opening message based on ad parameters
- Trackable end-to-end: ad impression → click → message → conversion

## Steps

### 1. Capture ad context on inbound
When a CTWA-originated message arrives, Meta includes `referral` in the webhook payload:
```json
{
  "referral": {
    "source_url": "https://fb.me/...",
    "source_type": "ad",
    "source_id": "<ad_id>",
    "headline": "<ad headline>",
    "body": "<ad body>",
    "media_type": "image|video",
    "media_url": "...",
    "thumbnail_url": "...",
    "ctwa_clid": "<unique click id>"
  }
}
```

Persist this on the first inbound message of any conversation that has it:
```sql
ALTER TABLE messages ADD COLUMN referral JSONB;
-- + populate ctwa_conversions on first such message
```

### 2. Build the conversions table
See WhatsApp v2.1 §27B for the schema:
```sql
CREATE TABLE ctwa_conversions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID,
  contact_id UUID NOT NULL REFERENCES contacts(id),
  ctwa_clid TEXT NOT NULL,
  ad_id TEXT NOT NULL,
  campaign_id TEXT,
  conversation_started_at TIMESTAMPTZ NOT NULL,
  qualified_at TIMESTAMPTZ,
  booking_at TIMESTAMPTZ,
  purchase_at TIMESTAMPTZ,
  purchase_amount_minor INTEGER,
  attribution_window_days INTEGER NOT NULL DEFAULT 7
);
```

### 3. Send conversion events back to Meta (Conversions API)
This is the critical step — without it, Meta's ad optimizer can't learn which ads produce revenue.

```typescript
async function sendCAPI(event: {
  event_name: "MessageReceived" | "Lead" | "Schedule" | "Purchase";
  ctwa_clid: string;
  contact_id: string;
  value?: number;
  currency?: string;
}) {
  await fetch(`https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION}/${process.env.META_PIXEL_ID}/events`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.META_CAPI_ACCESS_TOKEN}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        data: [{
          event_name: event.event_name,
          event_time: Math.floor(Date.now() / 1000),
          action_source: "business_messaging",
          messaging_channel: "whatsapp",
          user_data: { ctwa_clid: event.ctwa_clid },
          custom_data: event.value ? { value: event.value, currency: event.currency || "INR" } : undefined
        }],
        access_token: process.env.META_CAPI_ACCESS_TOKEN
      })
    });
}
```

### 4. Fire events at the right moments
- First inbound from CTWA → `MessageReceived`
- Contact qualified (your business logic — usually after a specific Flow submission or AI judgment) → `Lead`
- Booking created → `Schedule`
- Payment received → `Purchase` with value + currency

Hook these into your existing message/conversation/booking pipelines — every state transition fires its CAPI event.

### 5. Attribution dashboard
`/admin/ctwa` per-tenant:
- Funnel: ad → conversation → qualified → booked → paid (with conversion rates between steps)
- Cost per click (from Meta Ads API — pull spend data)
- Cost per qualified lead
- Cost per booking
- Average booking value
- ROAS = total purchase value / ad spend, by campaign

**Evidence:**
- One CTWA inbound captured with full referral payload (paste log)
- One CAPI event sent successfully (paste API response)
- Attribution dashboard rendered with at least one campaign's funnel
- Manual reconciliation: 5 CTWA conversations + their downstream conversions match what Meta reports

**Done condition:** Conversion events flowing both directions; client can see ROAS in the admin dashboard.

**What this enables for the client:**
- Without CAPI: Meta's optimizer guesses which ads work. CAC stays high.
- With CAPI: Meta sees "this ad → this conversation → ₹6500 booking" and optimizes future spend to similar audiences. CAC drops 30-60% over 2-3 weeks typically.
- This is THE selling point of WhatsApp bots over generic chat: end-to-end attribution.

**Anti-patterns:**
- Sending CAPI events without `ctwa_clid` — Meta can't tie them to the originating ad
- Firing `Lead` events for every conversation (not just qualified ones) — pollutes optimization
- Sending real money value as `Purchase` event for a non-paid action — distorts ROAS reports
- Skipping CAPI "for v1, we'll add it later" — by v2, the client has been burning ad budget unattributed for weeks
