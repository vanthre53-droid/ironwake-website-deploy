# QUALITY RATING PLAYBOOK — WhatsApp-specific

Meta scores every WhatsApp Business phone number GREEN / YELLOW / RED based on user behavior. A drop costs you throttling, template approvals slow down, and — if ignored — your number gets restricted permanently. This is the most underestimated risk in WhatsApp bot operations.

## What the ratings mean (June 2026)

| Rating | What it means | Effect |
|--------|---------------|--------|
| **GREEN (High)** | Users mostly engage positively | No restrictions; full daily conversation tier |
| **YELLOW (Medium)** | Concerning signals (blocks, reports, low replies) | 24-72hr warning window; messaging tier may downgrade |
| **RED (Low)** | Many users finding messages unwanted | Throttled to lower tier; templates harder to approve; if persistent → permanent restriction |
| **UNKNOWN** | New number, no signal yet | Starts at lower tier; rate-limited until rating stabilizes |

## What Meta is measuring (in priority order)

1. **Block + report rate** — users tapping "Block" or "Report" after receiving your message
2. **Low reply rate on template messages** — Meta reads this as spam
3. **Spam complaints from recipients** — directly reported to Meta
4. **"Not interested" responses** — explicit negative signal
5. **Send velocity changes** — sudden spikes look like spam patterns
6. **Send-to-block-rate ratio** — sending more to users who block at higher rates

## Monitoring (always-on)

### Webhook (preferred)
Subscribe to `phone_number_quality_update` webhook event. Meta pushes rating changes; you write every change to `quality_rating_history`.

### Polling (backup; some accounts don't get webhook events reliably)
Cron every 6 hours: `GET /{phone-number-id}?fields=quality_rating,messaging_limit_tier&access_token=...`. Store every reading.

### Alerts
- YELLOW → email to agency owner + dashboard banner + auto-freeze marketing template sends
- RED → P0 alert (interrupt-the-night) + auto-freeze ALL template sends + diagnose mandatory

## When rating drops — the recovery playbook

### Step 1: Diagnose (within 1 hour)
Pull the last 7 days of sends from `messages` table. Group by template. For each template:
- Sent count
- Delivered count
- Read count
- Reply count
- Block events
- Report events

Identify the template(s) with disproportionately bad metrics. That's your culprit (or one of them).

### Step 2: Identify the cause
Common patterns:
1. **Sent marketing template to people who didn't expect it.** Audit your opt-in source: did consent text actually authorize marketing? Did you import a list claiming "they're all opted in"? (You can't trust list imports — verify each contact has a real WhatsApp opt-in record.)
2. **Frequency too high.** Sending multiple templates per week to the same contacts, regardless of engagement.
3. **Template content reads as spam.** Generic offers, all-caps subjects, excessive emoji, urgency manipulation.
4. **Sent to wrong audience.** Segmentation broke; segment that should have received "renewals" got "new customer welcome" or similar.
5. **Wrong template category.** Marketing template sent as utility — Meta detects and penalizes.
6. **Outdated contact list.** Numbers that no longer use WhatsApp, sold their number, or churned customers. Returns "delivered but never read" pattern.

### Step 3: Stop the bleeding
- Pause the offending template(s) immediately — set `templates.status = 'paused'`
- If rating is RED: freeze ALL template sends globally for this WABA number until cause identified
- Continue serving 24-hour-window conversations (those are user-initiated, no risk)

### Step 4: Fix the root cause
- Audit + tighten opt-in source
- Reduce send frequency per contact
- Rewrite template to be more relevant + valuable
- Re-segment audience
- Resubmit template under correct category
- Clean contact list (remove no-longer-WhatsApp numbers)

### Step 5: Resume cautiously
- Send to a SMALL test segment first (10% of usual volume)
- Monitor metrics for 48 hours
- If quality holds: gradually scale back up over a week
- If quality drops again: stop, deeper diagnosis needed

### Step 6: Document
- Write up the incident in `docs/RUNBOOKS.md` under "WhatsApp quality rating recovery — past incidents"
- Capture: what dropped, root cause, fix, time to recovery
- Future incidents are faster to diagnose with this history

## Prevention (avoid the playbook altogether)

1. **Opt-in is real or it's nothing.** A check-box on a form is opt-in. An "I agree to receive marketing across all channels" buried in T&Cs is not (in most jurisdictions).
2. **Send less than you think you should.** "More touchpoints" sounds like marketing wisdom; on WhatsApp it kills your number.
3. **Always end conversations with a question.** Replies signal Meta the user is engaged. High reply rate = high quality.
4. **Marketing templates only on weekdays, business hours, local time.** Off-hours sends have lower engagement.
5. **Personalize meaningfully.** "Hi {{1}}" is the floor; tying content to actual user behavior is what works.
6. **Watch reply rate per template weekly.** A template whose reply rate is dropping is a warning before the quality rating drops.
7. **Don't send the same template to the same user >1×/week.** Cool-down logic in the send infrastructure.

## When rating won't recover

Sometimes the number is too damaged. In that case:
- Open a new WABA number
- Migrate contacts (with re-consent for marketing — old consent doesn't transfer cleanly)
- Take more time to build the new number's reputation slowly
- The old number can serve receive-only for existing conversations until they wind down
- Don't repeat the mistakes that damaged the first number

## Documentation requirements

Every WhatsApp project must have, in `docs/RUNBOOKS.md`:
- The recovery playbook (paste this whole document or link to it)
- Current quality rating + last reading time
- Per-template reply rate (last 30 days) — quick reference for diagnosis
- Pause/unpause runbook for marketing template sends
- Escalation contact for the client when their number drops to YELLOW
