# SECURITY BASELINE — WhatsApp Kit (V7 baseline + WhatsApp overlays)

Start with V7 Kit `rules/SECURITY_BASELINE.md`. WhatsApp adds:

## §W1. WABA token hygiene
- WABA access tokens stored in Infisical (or `.env` server-side) — NEVER in client code, repo, or logs
- Each tenant (if multi-WABA) has its own token reference path
- Token rotation every 60 days; calendar reminder in Infisical
- Webhook verify_token rotated when WABA is reconfigured

## §W2. Webhook signature verification
- Meta signs every webhook with HMAC-SHA256 in `X-Hub-Signature-256` header
- Verify against the raw request body BEFORE JSON parsing
- Tampered → 401 + log to `security_events`
- Verification is mandatory in dev too — don't disable in any env

## §W3. Flows encryption (if Flows used)
- Asymmetric crypto: Flow public key uploaded to Meta, private key in Infisical
- Decrypt every Flow data exchange payload server-side
- Tampered or undecodable payload → reject with proper error response
- Key rotation: every 12 months per Meta recommendation

## §W4. Conversation data + PII
- Phone numbers stored hashed if not needed in plaintext for sending (or store plaintext + apply RLS strictly)
- Conversation transcripts in Langfuse: scrub PII (names beyond contact, emails, addresses) before logging
- Recordings? — N/A; WhatsApp is text + media, no voice recordings
- Media uploads from users: AV-scanned before processing (claudine/clamav); user-uploaded files NEVER passed to Claude with system-level access

## §W5. Opt-in / opt-out infrastructure
- Per-channel opt-in stored with timestamp, source, exact text shown
- "STOP" message handling: immediate write to `opt_outs`, suppression of all future marketing templates within 60s
- Re-engagement after opt-out: only allowed if user explicitly opts back in
- Audit log on every consent state change

## §W6. Multi-tenant isolation (multi-WABA agency)
- RLS on every tenant table (V7 baseline rule, restated)
- Webhook routing by `phone_number_id` → tenant — no cross-tenant data leakage
- Token loading scoped per request; never load all tenants' tokens into memory at once
- Admin UI: agency-admin role required for cross-tenant view; client-admin sees only their tenant

## §W7. WhatsApp Pay (if used)
- Idempotency on payment webhook (same `reference_id` → same result, no double-processing)
- Payment status transitions strict — `success` cannot regress to `pending`
- Refund flow: auth check + reason logged + audit entry
- KYC: client (not you) is the merchant of record; their PAN + GST verified by Meta during onboarding

## §W8. Click-to-WhatsApp Ads (if used)
- Conversions API token stored in Infisical
- Attribution data (ctwa_clid, ad_id, campaign_id) NOT shared cross-tenant
- Conversion events sent to Meta only for the relevant tenant's ads

## §W9. Pre-deploy WhatsApp security checklist (Gate D additions)
- [ ] Webhook signature verification tested with tampered payload (must reject)
- [ ] WABA tokens not in repo (`gitleaks` clean) + not in `NEXT_PUBLIC_*` (`grep` empty)
- [ ] Flows decryption tested (if Flows used)
- [ ] Opt-in records present for any marketing template send
- [ ] STOP handling tested end-to-end
- [ ] Cross-tenant read attempt fails (if multi-WABA)
- [ ] 5 injection tests pass via real WhatsApp send (not just text simulation)
