# VERIFICATION GATES — WhatsApp Kit (extends V7 A–E with WhatsApp F–H)

## GATES A–E (from V7 Kit, apply here)
- **A — DB:** schema for contacts, conversations, messages, templates, flows, opt_ins, quality_rating_history (+ tenant_id if multi-WABA) + cross-tenant RLS proven
- **B — Webhook + send routes:** Meta signature verification, idempotency on `wamid`, rate limiting, retries with exponential backoff
- **C — Admin UI:** Lighthouse + a11y + screenshots; pages for conversations, templates, flows, quality dashboard, broadcasts
- **D — Security:** 5 injection tests, WABA token in Infisical only, RLS proven, no PII in logs
- **E — Deploy:** production URL up, Sentry + Langfuse receiving events, webhook URL configured in Meta console

## GATE F — TEMPLATE APPROVAL (WhatsApp-specific)
Evidence required:
- All Day-1 templates submitted to Meta with correct category
- Each template's approval status documented (`templates.status`)
- Rejected templates: reason captured + fix proposed + resubmitted
- Sample template renderings verified per device (Android, iOS, web)
- At least one of each category type tested: utility, marketing, authentication

## GATE G — QUALITY RATING (blocks production)
Evidence required:
- `quality_rating_history` populated with at least 24h of readings
- Quality rating GREEN at deploy time
- Monitoring webhook subscribed + tested (test event handled correctly)
- Alert wiring verified: simulated YELLOW → admin email triggered + dashboard banner shown
- Runbook in `docs/RUNBOOKS.md` for "what to do if rating drops to YELLOW/RED"

## GATE H — FLOWS ENCRYPTION (only if Flows used; blocks production)
Evidence required:
- Flow JSON files validated against Meta's schema (use Meta's Flow Builder)
- Asymmetric crypto for Flow data exchange wired: public key uploaded to Meta, private key in Infisical
- Decryption tested: a real Flow submission decoded successfully on your endpoint
- Tampered Flow payload rejected (signature/decryption fails → 401)
- Each Flow's submission outcome verified end-to-end (form submitted → record created in DB → confirmation message sent)

## ORDER
A → B → C → D → E → F → G → H (skip H if no Flows used).
