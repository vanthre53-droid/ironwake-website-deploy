# VERIFICATION GATES — Voice Kit (extends V7 Gates A–E with voice-specific F–H)

Same rule: claims require evidence. No evidence → not done.

---

## GATE A — DATABASE (from V7 Kit, applies here)
See V7 Kit `rules/VERIFICATION_GATES.md`. Voice projects add these tables:
- `voice_calls`, `call_segments`, `call_tools_called`, `call_qa_scores`, `outbound_consent`, `suppression_list`, `outbound_campaigns`, `scheduled_callbacks`, `call_agents_used` (if multi-agent)
All must pass cross-tenant isolation test if multi-tenant.

---

## GATE B — TOOL ROUTES (voice's API gate)
Same as V7 Gate B with voice additions:
- Each tool route p95 < 800ms (verified via load test, not single curl)
- Webhook signature from voice platform (Vapi/Retell) verified
- Idempotent: same `platform_call_id` processed twice → same result, no duplicate DB writes

---

## GATE C — ADMIN UI (from V7 Kit, applies here)
- Standard Lighthouse + axe + screenshots
- Voice-specific pages: `/admin/calls`, `/admin/calls/[id]` (with audio player), `/admin/agents/[id]/test`, `/admin/qa`

---

## GATE D — SECURITY (from V7 Kit baseline + voice overlays)
- All baseline checks
- 5 injection tests pass — run against the voice agent via test call (not just text)
- TCPA pre-dial checks proven via test: attempting to dial a suppressed number → blocked + logged
- If voice clone used: signed consent on file
- Recording storage access scoped (signed URLs, 15-min expiry)

---

## GATE E — DEPLOY (from V7 Kit, applies here)
Standard Gate E + voice-specific:
- Inbound test call: end-to-end with real STT/LLM/TTS, voice-to-voice p95 < 1000ms
- Outbound test call (if outbound enabled): canDial check confirmed, AMD working, voicemail drop tested

---

## GATE F — LATENCY (voice-specific, blocks production)
Evidence required:
- 50+ real calls' latency data, broken down by layer (STT, LLM TTFT, LLM total, tool route, TTS)
- p50, p95, p99 per layer
- Voice-to-voice p95 < 1000ms — proven across the 50 calls
- If breached: per-layer breakdown showing which layer caused the breach + fix evidence

---

## GATE G — CALL QUALITY (voice-specific, blocks production)
Evidence required:
- 20+ test calls scored by the call-critic agent
- Overall average score ≥ 80
- Compliance score ≥ 95 across all 20 calls (zero tolerance for compliance failures)
- Hallucination score ≥ 90
- Failures (if any) traced to root cause + fixed

---

## GATE H — TCPA / OUTBOUND (only if outbound enabled, blocks production)
Evidence required:
- `outbound_consent` table populated with at least one valid consent row (showing schema correctness)
- `canDial()` test suite passes: no consent → blocked, suppressed → blocked, outside window → blocked, frequency cap → blocked, valid path → allowed
- DNC scrubbing job tested against fixture suppression list
- AI disclosure verified in test call's first sentence
- AMD + voicemail drop tested with answering machine fixture

---

## ORDER
For voice projects: A → B → C → D → E → F → G → H (skip H if no outbound).

A skipped gate cannot be "made up" by passing a later one. Each gate is independently mandatory.
