# SECURITY BASELINE — Voice Kit (V7 baseline + voice overlays)

Start with V7 Kit `rules/SECURITY_BASELINE.md` — every item there applies. Voice adds:

## §V1. Call recording handling
- Recordings contain voice biometrics — treated as PII
- Storage: signed URLs only, 15-minute expiry, never public
- Retention: per client policy in `client_context.md` (default 90 days, then archive)
- Deletion: per-call DELETE endpoint for GDPR/CCPA Right to Delete
- Mirror recordings from Vapi/Retell to Supabase Storage on call end (so you control retention, not the platform)

## §V2. Voice clone consent (if used)
- Written consent template signed BEFORE clone is created (see Voice v2.1 §30B)
- Voice fingerprint + ElevenLabs voice_id stored in `voice_clones` table
- Revocation endpoint: deletes from ElevenLabs + swaps production to stock persona within 60s
- Never clone: competitor voices, public figures, anyone without written consent

## §V3. TCPA + One-to-One Consent (US outbound)
- `outbound_consent` table populated with: contact, channel, exact consent text, method, source URL, IP, timestamp
- `canDial()` server-side function MUST be called before EVERY outbound dial — no bypass
- Suppression list (DNC + state lists + internal opt-outs) checked on every dial
- Time-zone aware call windows: never dial outside 9am-8pm local (TCPA hard limit)
- AI disclosure as the first sentence of every consumer outbound call

## §V4. PHI / HIPAA (if healthcare niche)
- BAA in place with: Supabase (Team+), Vapi/Retell (if available — verify per provider), Anthropic (enterprise/ZDR tier), ElevenLabs (Enterprise BAA), Deepgram (Enterprise BAA)
- PHI never in: Sentry events, Langfuse traces, application logs
- PII scrubbing on every logged transcript before storage in Langfuse
- Audit log on every PHI access (`audit_logs` table)

## §V5. Carrier + STIR/SHAKEN
- Outbound calls in US must carry attestation B or A (not C — looks like spam)
- Use a carrier that signs your calls (Twilio, Plivo, Telnyx all do)
- Caller ID must match the calling entity — do not spoof
- Monitor "spam likely" labeling — request relief from carriers if labeled

## §V6. Voice authentication caveats
- Voice biometrics are NOT a sufficient authentication factor in 2026 — deepfakes are too easy
- Never use voice match as the only verification for sensitive actions
- For account access: voice + knowledge factor + (ideally) a one-time code

## §V7. The 5 injection tests on a voice surface
- Run by dialing the production number with test inputs (or use platform test mode)
- Pre-seeded data injection (Test 4) requires test data carefully scoped to test tenant
- Document results in `evals/injection_results.md` with date + commit + call SID

## §V8. Vapi / Retell API key hygiene
- Platform API keys (Vapi/Retell) live in Infisical or server-side env, never in client code
- Webhook signature verification: Vapi uses `X-Vapi-Signature`; Retell uses `X-Retell-Signature`; verify on every webhook
- Rotate keys every 90 days; calendar reminder via Infisical

## §V9. Pre-deploy voice security checklist (Gate D additions)
- [ ] Recording retention policy documented + enforced
- [ ] Consent records present (if voice clone)
- [ ] TCPA infrastructure verified (if outbound enabled)
- [ ] STIR/SHAKEN attestation confirmed (if US outbound)
- [ ] BAA in place (if healthcare)
- [ ] 5 injection tests passed via real test calls
- [ ] PII scrubbing tested on a sample transcript
