# LATENCY BUDGET — voice-specific

Voice is a real-time pipeline. Each layer eats milliseconds. If the budget is breached, the caller feels it as awkward silence or talk-over. Latency is not "nice to have" — it's the difference between an agent that feels alive and one that feels broken.

## p95 targets per layer (memorize)

| Layer | Target | Critical threshold |
|-------|--------|--------------------|
| Endpointing (caller stopped speaking) | 500–700ms (configurable) | Set per language — Hindi/Tamil need longer; English 500ms |
| STT (Deepgram Nova-3) | < 250ms | > 350ms → switch model or check audio bitrate |
| Network round-trip | < 100ms | > 200ms → check edge region for STT/TTS providers |
| LLM TTFT (Claude) | < 300ms | > 500ms → prompt cache broken; system prompt too long |
| LLM full response | < 500ms (cache hit) / < 800ms (miss) | > 1000ms → cap `max_tokens` at 200; switch Sonnet→Haiku for simple turns |
| Tool routes | < 800ms p95 | > 1000ms → DB query missing index; external API slow |
| TTS first audio chunk (ElevenLabs Turbo v2.5) | < 250ms | > 400ms → Multilingual v2 instead of Turbo? unnecessary if English-only |
| TTS full audio | < (audio duration × 1.0) | Streaming should keep up; if not, network/provider |
| **Voice-to-voice total p95** | **< 1000ms** | **> 1500ms = ship-blocker** |

## How to measure

Each call writes to `voice_calls`:
```sql
stt_p95_ms INTEGER,
llm_ttft_p95_ms INTEGER,
llm_total_p95_ms INTEGER,
tts_p95_ms INTEGER,
tool_route_p95_ms INTEGER,
voice_to_voice_p50_ms INTEGER,
voice_to_voice_p95_ms INTEGER
```

`/admin/latency` dashboard surfaces per-layer p95 over rolling 24h. Each layer is its own line on a chart so you can see which layer is the bottleneck.

## When the budget breaks

1. **Identify which layer breached** (don't guess — look at the per-layer p95).
2. **Form ONE hypothesis** (the debugger agent's process):
   - STT slow → audio bitrate too low? Wrong model? Network egress region wrong?
   - LLM TTFT slow → cache busted (changed prompt? changed tool order?)
   - LLM full slow → max_tokens too high? Model too big for the turn?
   - Tool slow → DB query missing index? External API down?
   - TTS slow → wrong voice model? streaming not enabled?
3. **Fix the bottleneck.** Don't optimize layers that aren't the problem.
4. **Re-measure** 10 calls. If still breached, iterate.

## What NOT to do

- Don't accept "it's slow because LLM is slow" — the LLM has predictable latency given caching + max_tokens. If it's slow, something is wrong.
- Don't add features that breach the budget "for now" — they stay slow.
- Don't blame the network without measuring — usually it's prompt cache or model choice.
- Don't switch providers without measuring the current one's per-layer breakdown.

## Cost of breach

- Voice-to-voice >1500ms → callers hang up; client cancels contract
- Compliance latency >2s on disclosure → could be argued as not "immediate" (legal risk in some jurisdictions)
- Cumulative >2x of budget over a call → AI cost balloons (more tokens, slower turns)

Latency is the leading indicator of every other voice problem. Monitor it ruthlessly.
