#!/usr/bin/env bash
# Agency Kit VOICE — new voice agent project bootstrap
# Usage: ./scripts/new-project.sh <project-slug> [client-name] [platform: vapi|retell|omnidim]
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <project-slug> [\"Client Name\"] [vapi|retell|omnidim]"
  echo "Example: $0 sunrise-dental-voice \"Sunrise Dental\" vapi"
  exit 1
fi

SLUG="$1"
CLIENT_NAME="${2:-$SLUG}"
PLATFORM="${3:-vapi}"
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET_DIR="../${SLUG}"

if [[ -d "$TARGET_DIR" ]]; then
  echo "Error: $TARGET_DIR already exists. Aborting."
  exit 1
fi

case "$PLATFORM" in vapi|retell|omnidim) ;; *) echo "Platform must be vapi, retell, or omnidim"; exit 1 ;; esac

echo "[1/9] Creating project: $TARGET_DIR (platform=$PLATFORM)"
mkdir -p "$TARGET_DIR" && cd "$TARGET_DIR"

echo "[2/9] Next.js 14 admin shell"
pnpm create next-app@latest . --typescript --tailwind --eslint --app --src-dir --import-alias "@/*" --use-pnpm --no-turbo

echo "[3/9] Core deps + voice deps"
pnpm add @supabase/supabase-js @supabase/ssr @anthropic-ai/sdk zod @upstash/ratelimit @upstash/redis pino pino-pretty
pnpm add @deepgram/sdk elevenlabs
case "$PLATFORM" in
  vapi)    pnpm add @vapi-ai/server-sdk ;;
  retell)  pnpm add retell-sdk ;;
  omnidim) echo "OmniDimension: MCP-based, no SDK install needed" ;;
esac
pnpm add -D @types/node tsx vitest @vitest/ui @testing-library/react @testing-library/jest-dom playwright

echo "[4/9] Copying kit (CLAUDE.md, rules, skills, agents, memory)"
cp "$KIT_DIR/CLAUDE.md" .
cp -r "$KIT_DIR/.claude" .
cp -r "$KIT_DIR/rules" .
cp "$KIT_DIR/settings.json" .claude/

echo "[5/9] progress.md"
cat > progress.md <<EOF
# PROGRESS — ${CLIENT_NAME} voice agent (${SLUG})
**Status:** scaffolded · **Platform:** ${PLATFORM} · **Last updated:** $(date -u +"%Y-%m-%d %H:%M UTC")
**Build order:** DB → Platform config → Tool routes → Admin UI → Gates F (latency) + G (quality) + H (TCPA if outbound)
## Completed
- [x] Step 00: Scaffolded with Agency Kit Voice + ${PLATFORM} SDK
## Up next
- [ ] Step 01: Fill in client_context.md (business, niche, language, hours, persona)
- [ ] Step 02: Supabase project + .env.local
- [ ] Step 03: DB schema (voice_calls, call_segments, call_tools_called, call_qa_scores, outbound_consent if outbound)
- [ ] Step 04: Gate A (DB)
- [ ] Step 05: Configure ${PLATFORM} assistant (system prompt + tool definitions)
- [ ] Step 06: Build tool routes
- [ ] Step 07: Gate B (tool routes)
- [ ] Step 08: Admin UI for calls + QA dashboard
- [ ] Step 09: Gate C (UI), Gate D (security), Gate F (latency), Gate G (quality)
- [ ] Step 10: Gate E (deploy)
EOF

echo "[6/9] .env.local template"
cat > .env.local.example <<EOF
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
# Anthropic
ANTHROPIC_API_KEY=
# Voice platform (${PLATFORM})
$(case "$PLATFORM" in
  vapi)    echo "VAPI_API_KEY="; echo "VAPI_WEBHOOK_SECRET=" ;;
  retell)  echo "RETELL_API_KEY="; echo "RETELL_WEBHOOK_SECRET=" ;;
  omnidim) echo "OMNIDIM_MCP_URL="; echo "OMNIDIM_API_KEY=" ;;
esac)
# STT / TTS
DEEPGRAM_API_KEY=
ELEVENLABS_API_KEY=
ELEVENLABS_VOICE_ID=
# Upstash, Sentry, Langfuse
UPSTASH_REDIS_REST_URL=
UPSTASH_REDIS_REST_TOKEN=
SENTRY_DSN=
LANGFUSE_PUBLIC_KEY=
LANGFUSE_SECRET_KEY=
LANGFUSE_HOST=https://cloud.langfuse.com
EOF
cp .env.local.example .env.local
echo -e ".env.local\n.env" >> .gitignore

echo "[7/9] check-env.ts validator"
mkdir -p scripts
cat > scripts/check-env.ts <<'EOF'
import { z } from "zod";
const Env = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(20),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(20),
  ANTHROPIC_API_KEY: z.string().startsWith("sk-ant-"),
  DEEPGRAM_API_KEY: z.string().min(10),
  ELEVENLABS_API_KEY: z.string().min(10),
});
const parsed = Env.safeParse(process.env);
if (!parsed.success) {
  console.error("❌ ENV VALIDATION FAILED:\n", parsed.error.flatten().fieldErrors);
  process.exit(1);
}
console.log("✅ Env validated");
EOF

echo "[8/9] Initial directories for voice-specific code"
mkdir -p src/app/api/voice/{webhooks,tools} src/lib/{voice,crm,observability} evals
touch src/lib/voice/{latency-budget.ts,call-qa.ts} evals/injection_results.md

echo "[9/9] First commit"
git init -q && git add -A && git commit -q -m "chore: scaffold voice agent (${PLATFORM}) from Agency Kit Voice for ${CLIENT_NAME}"

echo ""
echo "✅ Voice agent project ready at: $TARGET_DIR"
echo "Platform: $PLATFORM"
echo ""
echo "NEXT STEPS:"
echo "  1. cd $TARGET_DIR"
echo "  2. Fill .env.local with real values"
echo "  3. Open in Claude Code — CLAUDE.md + progress.md load automatically"
echo "  4. Run the build prompt generator (File 40 + 40b addendum) to produce the spec"
