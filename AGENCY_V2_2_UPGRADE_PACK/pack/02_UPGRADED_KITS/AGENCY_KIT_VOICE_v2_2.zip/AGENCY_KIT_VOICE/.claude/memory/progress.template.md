# PROGRESS — <client name> voice agent

**Status:** <scaffolded | building | gate-X-passed | deployed | maintenance>
**Platform:** <vapi | retell | omnidim>
**Last updated:** <YYYY-MM-DD HH:MM UTC>
**Current gate:** <A | B | C | D | E | F | G | H>

---

## Gate progress (voice-specific)
- [ ] Gate A — DB schema (voice_calls, call_segments, call_tools_called, call_qa_scores, +outbound tables if applicable)
- [ ] Gate B — Tool routes (each <800ms p95, signed webhooks)
- [ ] Gate C — Admin UI (calls list, call detail with audio player, QA dashboard)
- [ ] Gate D — Security (5 injection tests via real test calls, recording handling, BAA if PHI)
- [ ] Gate E — Deploy + observability
- [ ] **Gate F — Latency** (50 calls, voice-to-voice p95 < 1000ms, per-layer breakdown attached)
- [ ] **Gate G — Call quality** (20 calls scored, average ≥80, compliance ≥95)
- [ ] **Gate H — TCPA** (outbound only — canDial suite passes, AI disclosure verified)

---

## ✅ Completed
- [x] <step> — <outcome>

## 🟡 In progress
- [ ] <current step>

## 🔜 Up next
- [ ] <step>

## ⛔ Blockers
- <description>

## 📞 Voice-specific metrics being tracked
- Voice-to-voice p95 (last 24h): <ms>
- Cache hit rate (last 24h): <%>
- Cost per call: $<amount>
- Call QA overall score (last 24h): <0-100>
- Compliance score (last 24h): <0-100>

## 📜 Decisions log
- <YYYY-MM-DD> — <decision> — <why>

## 🚧 Open questions for the user
- <question>

## 🔁 Reversions
- <YYYY-MM-DD> — <what didn't work> — <why> — <what we did instead>
