# SKILL: call_qa_scoring

**When to use:** Every voice project. Auto-grades every completed call. Mandatory by Gate G.

**Reference:** Voice v2.1 Section 27 — 5 dimensions, 0-100 each.

**Steps:**

1. **Create `call_qa_scores` table** (schema in Voice v2.1 §27B).

2. **Build the scoring prompt** (uses Sonnet 4.6, JSON-only output):
```
You are a quality auditor for an AI voice agent. Given a call transcript and metadata, score the call on 5 dimensions (0-100 each).

DIMENSIONS:
1. Resolution — did the caller achieve their stated goal?
   - 100: clear goal achieved (booked / answered / cleanly transferred / message taken)
   - 50: partial (some info given, no closure)
   - 0: caller's need unmet

2. Compliance — did the agent follow ALL the rules?
   - 100: AI disclosure present, prices only from DB, confirms before action, offers human handoff
   - <100: any rule violated

3. Hallucination — did the agent invent anything not in tools/data?
   - 100: every claim grounded in tool returns or stable knowledge
   - <100: invented prices, hours, services, policies, or names

4. Sentiment — caller's emotional state
   - 100: positive throughout
   - 50: neutral
   - 0: frustrated or angry by end

5. Latency — was voice-to-voice p95 < 1000ms?
   - 100: yes throughout
   - <100: number of turns where it breached / total turns

INPUT:
- Transcript: <transcript>
- Per-layer p95 latency: <ms breakdown>
- Tool returns: <list of what tools returned>
- DB state at call time: <relevant prices / hours / etc.>
- AI disclosure expected as first sentence: yes
- Niche-specific rules: <e.g. "must say 'not legal advice' for legal questions">

OUTPUT (JSON only, no prose):
{
  "resolution_score": <0-100>,
  "compliance_score": <0-100>,
  "hallucination_score": <0-100>,
  "sentiment_score": <0-100>,
  "latency_score": <0-100>,
  "overall_score": <weighted: resolution*0.3 + compliance*0.3 + hallucination*0.2 + sentiment*0.1 + latency*0.1>,
  "failures": [
    { "dimension": "compliance", "detail": "agent did not say 'not legal advice' after caller asked about case viability" }
  ]
}
```

3. **Build the cron job** — runs every 15 min:
```typescript
// src/lib/voice/qa-cron.ts
import Anthropic from "@anthropic-ai/sdk";
const anthropic = new Anthropic();

export async function scoreCallsCron() {
  const unscored = await db.voiceCalls.findMany({
    where: { status: 'completed', qaScore: null },
    take: 50  // limit per run
  });
  
  for (const call of unscored) {
    const transcript = await assembleTranscript(call.id);
    const layerLatency = { stt: call.sttP95Ms, llmTtft: call.llmTtftP95Ms, /* ... */ };
    const toolReturns = await db.callToolsCalled.findMany({ where: { callId: call.id }});
    const dbState = await getRelevantDbState(call);
    
    const result = await anthropic.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      system: [{ type: "text", text: SCORING_PROMPT, cache_control: { type: "ephemeral" }}],
      messages: [{ role: "user", content: JSON.stringify({ transcript, layerLatency, toolReturns, dbState }) }]
    });
    
    const scores = JSON.parse(extractJson(result.content[0].text));
    await db.callQaScores.create({ data: { callId: call.id, ...scores }});
    
    if (scores.overall_score < 70) await flagForReview(call.id);
    if (scores.compliance_score < 90) await alertP0(call.id, scores.failures);
  }
}
```

4. **Wire the cron.** Vercel Cron job → `/api/voice/qa-cron` → `scoreCallsCron()`. Schedule: every 15 minutes.

5. **Build the admin QA dashboard:**
   - `/admin/qa` — table of all scored calls with filter by score range
   - Click → call detail with transcript + audio + score breakdown + failures list
   - Heatmap: avg score per day of week / time of day (identify patterns)

6. **Weekly digest** — cron Monday 9am:
   - Total calls last 7 days
   - Average overall score (with trend vs prior week)
   - Calls under 70 (links)
   - Top 3 failure modes from `failures` JSON aggregated
   - Email to agency owner + client

**Evidence (Gate G):**
- Schema created
- 20+ test calls scored
- Average overall score ≥ 80
- Compliance score ≥ 95 across all 20
- Sample call with score breakdown + failures detail
- Weekly digest email rendered (sample)
- Dashboard screenshot

**Done condition:** Cron running, scores accumulating, dashboard live, weekly digest tested.

**Tuning loop:**
When you see a pattern of low scores in one dimension:
- Compliance failures → tighten the system prompt rules for that scenario; add explicit refusal pattern
- Hallucination → reduce the agent's "freedom" — more tools, fewer cases where it answers from training
- Resolution low → tool failures? caller language mismatch? agent gives up too quickly?
- Sentiment dropping → look at long calls or repeated tool failures making caller wait

Don't just look at averages — look at the failure JSON. That's where the real signal lives.
