# SKILL: voice_persona_design

**When to use:** Picking + customizing the agent's persona for the client's niche. After client_context.md is filled in.

**Reference:** Voice v2.1 Section 26 ships ready personas per niche. Start there.

**Steps:**

1. **Pick the base archetype** from the persona library (Voice v2.1 §26):
   - Dental → Sarah (warm, anxiety-aware) or Priya (bilingual EN+HI)
   - HVAC → Mike (direct dispatcher) or Maria (Spanish-primary)
   - Real estate → Alex (energetic lead qualifier)
   - Law → Michael (calm, never casual)
   - Restaurant / Salon / Gym → Riya (friendly booking assistant)

2. **Customize for the specific client** (don't just paste the archetype):
   - Name: match the client's brand if they have a preference; otherwise use the archetype name
   - Voice characteristics: match the brand voice in `client_context.md` (warm vs bold vs playful vs calm)
   - Pace: medical/legal → slower; HVAC/dispatch → faster
   - Greeting: include the client's exact business name and the persona's introduction in one sentence
   - Anxiety/emergency cues: add domain-specific keywords (dental: "scared, hurts, nervous"; HVAC: "no heat, flooding, smell gas")

3. **Choose the ElevenLabs voice:**
   - Stock voice (no consent needed): pick from ElevenLabs library — listen to 3-5 candidates, pick the one matching brand
   - Cloned voice (consent required — see `voice_clone_consent_flow` skill): voice owner records 1-3 minutes of clean audio
   - Multilingual v2 if the agent must speak >1 language OR a language Turbo doesn't handle well

4. **Pick the right model:**
   - `eleven_turbo_v2_5` — English-only, lowest latency, cheapest. Default for English-only agents.
   - `eleven_multilingual_v2` — non-English or code-switching. Higher latency (~50-100ms more) and ~2× cost.

5. **Tune the voice parameters:**
   - `stability` 0.5 default — increase to 0.7 for consistent corporate voice, decrease to 0.3 for emotional range
   - `similarity_boost` 0.75 default — higher = more like the original voice (only matters for cloned voices)
   - `style` 0.0 default — only Multilingual v2; controls expressiveness
   - `use_speaker_boost` true — adds clarity at the cost of a tiny latency increase

6. **Write the system prompt persona block:**
```
You are ${persona.name}, an AI assistant for ${clientName}, a ${niche} in ${location}.

Your tone is ${persona.tone}.
Your pace is ${persona.pace}.

Always identify yourself as an AI on the first turn.
Never quote prices that are not in the database — use the get_services tool.
Always confirm before booking, paying, or sending any message.
${niche-specific rules from client_context.md}

If the caller seems frustrated, offer to transfer to a human immediately.
If the caller asks for a human at any time, transfer without friction.
```

7. **Test with 5 different caller types** before shipping:
   - Polite + clear caller
   - Frustrated caller
   - Confused caller (rambling, multiple intents)
   - Edge-case caller (asks something outside scope)
   - Code-switching caller (if multi-language)

**Evidence:**
- The final persona block in the system prompt
- Voice ID + ElevenLabs voice config
- 5 test call recordings covering the caller types above
- Call QA scores from those 5 calls — overall ≥80, compliance ≥95

**Done condition:** Persona feels natural to the client when they listen to test calls. They'd be comfortable putting this voice on their business line.

**What separates good personas from bad:**
- Specificity. "Warm" alone is vague. "Warm, unhurried, anxiety-aware" is actionable.
- Behavioral rules, not adjectives. "Acknowledges fear before answering" is testable. "Empathetic" is not.
- Domain-specific cues. Dental anxiety cues ≠ HVAC emergency cues. Generic personas perform generically.
- One name, one identity. Don't have the agent say "I'm Claude" in some places and "Sarah" in others.
