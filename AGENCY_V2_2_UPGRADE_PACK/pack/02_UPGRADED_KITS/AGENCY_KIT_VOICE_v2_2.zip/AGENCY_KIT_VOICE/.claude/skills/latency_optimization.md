# SKILL: latency_optimization

**When to use:** Voice-to-voice p95 has breached or is approaching 1000ms. Or any single layer is breaching its budget.

**Reference:** `rules/LATENCY_BUDGET.md` — per-layer targets.

**Diagnostic process (follow in order — do NOT guess):**

1. **Confirm the breach.** Pull last 24h of calls. Per-layer p95 from `voice_calls` table. Identify which layer (STT, LLM TTFT, LLM total, tool route, TTS) is breaching.

2. **Look at the distribution, not just p95.** If p50 is fine and p95 is bad, it's tail latency (sporadic slow calls) — different problem from "everything is slow."

3. **Identify the bottleneck layer** — fix THAT, not other layers.

## STT slow (> 350ms p95)
- Check audio bitrate from the platform; should be 16kHz, 16-bit, mono
- Confirm Deepgram model = `nova-3` (not older `nova-2`)
- Check Deepgram region — should match your STT egress region (avoid trans-Pacific hops)
- For non-English: confirm correct language code; auto-detect adds ~100ms

## LLM TTFT slow (> 500ms)
- Cache hit rate < 70% → cache is broken. Reasons:
  - System prompt changed between calls (any dynamic injection breaks the cache)
  - Tool definitions reordered (caches by full request prefix)
  - cache_control missing on stable blocks
- Verify: log `cache_read_input_tokens` per call; >0 = hit
- Fix: pin system prompt + tool order; rebuild cache_control wiring

## LLM full slow (> 1000ms)
- `max_tokens` too high — voice should be 150-250 max, never 1000
- Wrong model — using Sonnet for simple turns; switch routing rules: Haiku for dialogue, Sonnet only for tool-heavy turns
- Prompt is too long — long context = slow generation; trim system prompt, move stable knowledge to tools

## Tool route slow (> 800ms p95)
- Missing DB index — `EXPLAIN ANALYZE` the slow query
- N+1 query pattern — collapse to single query with join
- External API call inside the tool route — cache it; degrade gracefully if external is slow
- Cold start — warm up connections on app start, not first request

## TTS slow (> 400ms first audio chunk)
- Wrong model — using Multilingual v2 when Turbo v2.5 would do (Turbo is faster, English-only)
- `optimize_streaming_latency` = 0 — set to 3 for best balance
- Network egress — ElevenLabs region should match your app region; for US/India use US East endpoint
- Output too long — see LLM full slow above; shorter LLM output = faster TTS

## Network / regional latency
- App in Vercel Singapore + Deepgram/ElevenLabs in US East = guaranteed 200-300ms RTT
- For Indian SMBs: deploy app to Vercel Mumbai or Singapore region; use Deepgram + ElevenLabs US East (still better than reversing the topology because the providers are US-anchored)
- For US clients: app + providers all US East; latency essentially network-free

## Steps to execute the fix

1. Form ONE hypothesis about the slowest layer
2. Run an A/B: make the fix on a test agent; compare 10 calls before / 10 after
3. If improved → roll to production; re-measure 50 calls; commit
4. If not improved → next hypothesis

**Evidence:**
- Before/after per-layer p95 table
- 50 calls measured after the fix
- Voice-to-voice p95 back under 1000ms
- The specific change that fixed it (committed)

**Done condition:** Voice-to-voice p95 < 1000ms across 50 consecutive production calls.

**Anti-patterns:**
- Switching providers without identifying which layer is slow ("Vapi is slow" → "let's try Retell" → still slow because the bottleneck was your tool route)
- Reducing `max_tokens` so much that responses get cut off mid-sentence
- Caching user-specific data in the prompt (breaks privacy + breaks cache for everyone else)
- "We optimized!" without showing the data — every claim needs the before/after p95 table
