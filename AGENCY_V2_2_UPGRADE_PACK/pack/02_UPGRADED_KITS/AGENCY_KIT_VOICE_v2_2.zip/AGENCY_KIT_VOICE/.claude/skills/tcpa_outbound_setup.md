# SKILL: tcpa_outbound_setup

**When to use:** Wiring outbound calling infrastructure. ONLY if outbound is in scope. Required before Gate H.

**Reference:** Voice v2.1 Section 25 — the four hard rules + the `canDial()` checklist.

**The four hard rules (zero exceptions):**
1. Express prior written consent (per channel, per recipient, timestamped, source-tracked) for US consumer outbound
2. AI to consumers = robocall in US — illegal without that consent
3. Where AI auto-dial is restricted: manual-click architecture (human triggers, AI takes over once connected)
4. State + National DNC scrubbing + internal suppression list before every dial

**Steps:**

1. **Confirm jurisdiction + ruleset.** With the client, in writing:
   - Which countries are they calling? US? UK? AU? India?
   - Consumer outbound or B2B only?
   - If US consumer: One-to-One Consent Rule applies; document exactly where consent is collected and the text shown
   - If India: TRAI DLT registration for any commercial calls
   - If UK: PECR consent + Ofcom CLI rules
   - If AU: Privacy Act + DNCR

2. **Build the three tables** (from Voice v2.1 §25B): `outbound_consent`, `suppression_list`, `outbound_campaigns`

3. **Implement `canDial()`** — server-side function, ALL outbound dial paths go through it:
```typescript
// src/lib/voice/can-dial.ts
import { db } from "@/lib/db";

export interface DialResult { ok: boolean; reason?: string; }

export async function canDial(contactId: string, channel: 'voice' = 'voice'): Promise<DialResult> {
  // 1. Active consent for this channel?
  const consent = await db.outboundConsent.findFirst({
    where: { contactId, channel, revokedAt: null }
  });
  if (!consent) return { ok: false, reason: 'no_consent' };

  // 2. Suppression list?
  const contact = await db.contacts.findUnique({ where: { id: contactId }, select: { phone: true, timezone: true }});
  if (!contact) return { ok: false, reason: 'contact_not_found' };
  const suppressed = await db.suppressionList.findUnique({ where: { phone: contact.phone }});
  if (suppressed) return { ok: false, reason: 'suppressed' };

  // 3. Time-zone aware calling window (9am–8pm local; TCPA hard limit US)
  const localHour = nowInTimezone(contact.timezone || 'UTC').getHours();
  if (localHour < 9 || localHour >= 20) return { ok: false, reason: 'outside_window' };

  // 4. Frequency cap (not same number twice/day per campaign)
  const recent = await db.voiceCalls.findFirst({
    where: { contactId, createdAt: { gte: subHours(new Date(), 24) }, direction: 'outbound' }
  });
  if (recent) return { ok: false, reason: 'frequency_cap' };

  return { ok: true };
}
```

4. **Wire `canDial()` into EVERY outbound trigger:**
   - Manual click in admin UI → `canDial()` → if ok, trigger dial; if not, show reason
   - Cron-driven campaign → `canDial()` → if ok, queue dial; if not, log skip with reason
   - WhatsApp → voice handoff → `canDial()` → if not ok, fall back to scheduled callback

5. **DNC scrubbing.** Subscribe to a DNC scrubbing service (FreeDNCList, DNC.com, Contact Center Compliance — any compliant provider). Sync nightly into `suppression_list`.

6. **Consent capture infrastructure.** Wherever consent is gathered (web form, in-person, WhatsApp opt-in), store the row immediately with:
   - Exact text shown to the user (verbatim, not paraphrased)
   - URL + IP + user-agent + timestamp
   - Method (web_form, in_person, whatsapp_reply, paper_form_signed)

7. **Revocation flow.** Any "STOP" reply, "do not call" voice utterance, or web form opt-out → write `outbound_consent.revoked_at` + add phone to `suppression_list`. Effective within 60 seconds.

8. **AI disclosure** — first sentence of every consumer outbound call. Non-negotiable.

9. **AMD + voicemail drop** (Voice v2.1 §25D):
   - Enable AMD in Vapi/Retell config
   - On voicemail detected: either drop a pre-recorded VM (counts as a call under TCPA — same consent required) OR hang up silently
   - Log outcome in `voice_calls.ended_reason`

**Evidence (Gate H):**
- Schema for all three tables
- `canDial()` test suite passing: 5 scenarios (no consent, suppressed, outside window, frequency cap, valid)
- One consent record showing all required fields populated
- DNC scrub job logged in cron output
- One test call's transcript showing AI disclosure as first sentence
- AMD + voicemail drop verified via test call to a known voicemail

**Done condition:** All five test scenarios pass. No outbound dial path bypasses `canDial()`. AI disclosure verified.

**What gets you sued:**
- One outbound AI call without consent + the recipient reports → $500-$1500/call statutory damages under TCPA
- Pattern of consent violations → class action; settlements in the tens of millions
- Defense is documentation: if you can't produce the consent record on demand, you lose
- The client gets sued, but you (the agency) will be named — your indemnity clause should reflect this
