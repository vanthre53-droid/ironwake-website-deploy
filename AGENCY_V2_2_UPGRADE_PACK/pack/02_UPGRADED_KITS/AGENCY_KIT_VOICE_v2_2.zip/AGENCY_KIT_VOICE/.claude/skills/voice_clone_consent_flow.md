# SKILL: voice_clone_consent_flow

**When to use:** Client wants the agent to use a cloned voice (typically: the business owner's voice). Skip if using stock ElevenLabs voices.

**Reference:** Voice v2.1 Section 30 — consent template + allowed vs forbidden + revocation flow.

**Steps:**

## 1. Verify the request is allowed
**Allowed:**
- The business owner's own voice (signed consent from them)
- A staff member who has agreed in writing (signed consent)
- ElevenLabs Professional Voice Cloning (PVC) of an authorized person

**NEVER allowed (auto-refuse, escalate to user):**
- A competitor's voice
- A public figure (celebrity, politician, athlete)
- A real human who hasn't signed consent
- An "anonymous" voice that resembles a specific real person
- A deceased person's voice without the estate's written authorization

If the request falls outside "allowed" — STOP. Flag to user. Don't proceed.

## 2. Get the consent signed BEFORE recording any samples

Use the template in Voice v2.1 §30B. Counter-signed by both the voice owner and the agency. PDF stored in `client_context/` (off-repo; not committed) and referenced in `client_context.md` as "Voice clone consent: signed YYYY-MM-DD, on file at <secure location>."

Required fields on the consent:
- Voice owner's legal name + ID verification (passport/Aadhaar/driver's license number — NOT the document itself)
- Business name + relationship to voice owner (must be owner OR employee with written authorization)
- Authorized uses: inbound only? outbound? both? AI clones for marketing materials?
- Retention period: agreement duration + 30 days
- Revocation rights: 30 days' notice → full deletion from ElevenLabs + all backups
- Date + signatures

## 3. Record clean samples
- Quiet room, no background noise
- Quality microphone (USB condenser minimum, e.g. Blue Yeti)
- 16-bit 44.1kHz WAV
- Length: ElevenLabs PVC needs ≥30 min for best quality; Instant Voice Cloning works with 1-3 minutes (lower quality)
- Content: have them read 50-100 sentences covering varied phonemes (questions, statements, names, numbers, your business's common terms)

## 4. Create the clone in ElevenLabs
- Upload samples via ElevenLabs API or dashboard
- Use PVC tier (paid plan) for production agents
- Wait for training (PVC: hours; Instant: seconds)
- Test the resulting voice — read 10 sentences NOT in training set, verify quality

## 5. Store the voice metadata
```sql
CREATE TABLE voice_clones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES tenants(id),
  elevenlabs_voice_id TEXT NOT NULL UNIQUE,
  voice_owner_name TEXT NOT NULL,
  consent_signed_at TIMESTAMPTZ NOT NULL,
  consent_document_ref TEXT NOT NULL,  -- secure location (NOT the document itself)
  authorized_uses JSONB NOT NULL,       -- ['inbound', 'outbound', 'marketing_assets']
  retention_until TIMESTAMPTZ,
  status TEXT NOT NULL CHECK (status IN ('active', 'paused', 'revoked')),
  revoked_at TIMESTAMPTZ,
  revocation_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## 6. Build the revocation endpoint
- Admin clicks "Revoke" in `/admin/settings/voice` → confirms with reason
- Server calls `DELETE /v1/voices/{voice_id}` on ElevenLabs
- Updates `voice_clones.status = 'revoked'`, sets `revoked_at`
- Production agent swaps to stock fallback voice within 60s
- Confirmation email to voice owner + client
- Audit log entry

## 7. Document in client_context.md
```
## Voice clone
- Owner: <name>
- Consent signed: <YYYY-MM-DD>
- Authorized uses: <list>
- Fallback voice (if revoked): <stock voice_id>
- Revocation contact: <email>
```

**Evidence:**
- Signed consent document on file (reference in `client_context.md`)
- `voice_clones` row populated
- Test calls with cloned voice — quality acceptable to client
- Revocation flow tested end-to-end with a test voice
- Audit log entries verifiable

**Done condition:** Voice clone in production, consent on file, revocation works, fallback verified.

**What gets you in trouble:**
- Cloning without consent → ElevenLabs ToS violation (account ban) + civil liability (right of publicity, deepfake laws in TN, CA, NY)
- Cloning a deceased person without estate authorization → estate can sue
- Letting a revoked clone keep running → breach of contract + potential criminal exposure depending on use
- Storing the consent document in the repo → privacy + access control issue. Secure storage (1Password, encrypted Drive, etc.) and reference only in the repo.

**When in doubt, use a stock voice.** Stock voices are licensed by ElevenLabs, no consent needed, no liability exposure. The marginal "personalization" benefit of a cloned owner voice is often not worth the operational overhead — recommend stock unless the client specifically requests cloning.
