# SKILL: retell_agent_setup

**When to use:** Configuring a Retell agent. Use Retell when you need finer control over the LLM layer (LLM Webhook mode) or when Vapi pricing/region doesn't suit.

**Inputs:** same as vapi_agent_setup.

**Steps:**

1. **Create Retell LLM (the agent's brain):**
```typescript
import Retell from "retell-sdk";
const retell = new Retell({ apiKey: process.env.RETELL_API_KEY });

const llm = await retell.llm.create({
  general_prompt: SYSTEM_PROMPT,
  general_tools: TOOL_DEFINITIONS,
  begin_message: `Hi, this is ${persona.name}, an AI assistant for ${clientName}. How can I help you today?`,
  model: "claude-haiku-4-5",
  model_temperature: 0.3,
  model_high_priority: false,  // standard tier — bump to true for tighter latency SLA
  tool_call_strict_mode: true  // forces strict JSON tool args
});
```

2. **Create the agent (the voice + transcription layer):**
```typescript
const agent = await retell.agent.create({
  agent_name: `${clientSlug}-receptionist`,
  response_engine: { type: "retell-llm", llm_id: llm.llm_id },
  voice_id: "11labs-Adrian",  // or your custom voice_id
  voice_model: "eleven_turbo_v2_5",
  voice_temperature: 0.5,
  voice_speed: 1.0,
  responsiveness: 1.0,  // 0-1; higher = bot interrupts less, faster response
  interruption_sensitivity: 0.6,
  enable_backchannel: true,  // "uh-huh", "mhm" while caller talks
  ambient_sound: "office",  // or null; helps mask silence
  language: clientLanguage,
  webhook_url: `${process.env.NEXT_PUBLIC_APP_URL}/api/voice/retell/webhook`,
  end_call_after_silence_ms: 30000,
  max_call_duration_ms: 1800000,  // 30 min hard limit
  enable_voicemail_detection: true,
  voicemail_message: "Hi, this is [business]. We'll call you back. Thanks."
});
```

3. **Webhook handler** at `/api/voice/retell/webhook`:
   - Events: `call_started`, `call_ended`, `call_analyzed` (Retell's auto-analysis)
   - Verify `X-Retell-Signature` HMAC on every webhook
   - Same DB pattern as Vapi: insert/update `voice_calls`

4. **Tool calls** in Retell hit your tool routes the same way as Vapi (signed HTTPS endpoints).

5. **Phone number** assigned via Retell dashboard or `retell.phoneNumber.update()`.

**Key differences from Vapi:**
- Retell's "LLM Webhook" mode lets YOU host the LLM call — useful if you need custom routing
- Retell has built-in post-call analysis (sentiment, summary) — handy but verify cost
- Vapi's tool-call experience tends to be lower-latency; Retell's transcription is generally better
- For Indian SMBs with budget constraints: Vapi often cheaper; for US enterprise clients: Retell often preferred for reliability

**Evidence:**
- Retell agent + LLM IDs
- One test call recording + transcript
- Webhook signature verification confirmed
- Per-layer latency from one test call

**Done condition:** same as Vapi — test call works, p95 budget met, webhook signed.
