# SKILL: demo_clone_pipeline

**When to use:** Turning the flagship assistant into a prospect-branded demo (the personalization weapon). Target <2h/prospect → <30min by week 3.

**Reference:** Voice v2.2 Section 39 (modules/40c-VOICE_v2_2_CONSOLIDATED.md) + P5 build prompt.

**Steps:**
1. `config.json` per prospect (§39A contract) — every grounded fact carries its source URL; HUMAN eyeballs before deploy (mandatory).
2. Clone via API/MCP only (never dashboard): copy assistant → patch prompt (persona + greeting + disclosure with THEIR name + facts) → attach demo number.
3. Seed `entities` (tenant=slug) so the grounding lock works exactly as prod; redeploy branded site/widget via data-* config.
4. Verify: disclosure ✓ · THEIR price ✓ · absent-fact fallback ✓ · interrupt twice ✓. Record the 90-sec Loom.
5. `demo_registry` row; caps + 14-day auto-archive teardown.

**Evidence:** registry row + verify checklist + wall-clock time logged.
