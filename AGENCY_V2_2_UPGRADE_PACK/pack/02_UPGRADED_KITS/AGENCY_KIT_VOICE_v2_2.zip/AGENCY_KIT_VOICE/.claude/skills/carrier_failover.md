# SKILL: carrier_failover

**When to use:** Any production voice deployment. An alert with no failover is just a notification that you're down.

**Reference:** Voice v2.2 Section 35 (modules/40c-VOICE_v2_2_CONSOLIDATED.md).

**Steps:**
1. Primary + backup carrier/number per agent (number pools / SIP failover).
2. Synthetic health-check call every N minutes → failure marks primary unhealthy.
3. Auto-trigger: unhealthy OR >X% call-setup failures in Y minutes → new calls route to backup. Automatic, never manual — a human noticing at 2am is not a plan.
4. Inbound continuity: carrier-level forward of the primary number to backup.

**Evidence:** kill the primary in staging → new calls land on backup within one failed health check. Paste it.
