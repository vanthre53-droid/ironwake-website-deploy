# SKILL: barge_in_setup

**When to use:** EVERY voice agent, FIRST thing after platform config. The #1 "sounds robotic" failure and the demo decider. Latency <1s with no barge-in still sounds robotic.

**Reference:** Voice v2.2 Section 33 (modules/40c-VOICE_v2_2_CONSOLIDATED.md).

**Steps:**
1. Enable **yield-on-speech** (default): agent stops mid-sentence the moment the caller speaks. On Vapi/Retell it must be turned ON and tuned, never assumed.
2. Configure **acknowledge-and-continue** for compliance lines: AI disclosure, "not legal advice", price confirmations finish before yielding — never half-spoken.
3. **Backchannel tolerance:** "mm-hmm / yeah / okay" ≠ interruption; agent keeps talking.
4. Tune: interruption threshold HIGHER in noisy niches (HVAC/vans/restaurants), lower in quiet ones (law). Min-2-words-to-interrupt kills cough/noise false yields. Stacks on top of per-language endpointing (§23B).

**Evidence:** the Interrupter test (§33C): talk over the agent 5× → clean yield every time EXCEPT mid-disclosure; no talk-over-talk; disclosure never truncated.
