# SKILL: vapi_agent_setup

**When to use:** Configuring a Vapi assistant for an inbound/outbound voice agent. After Gate A (DB) passes.

**Inputs:**
- Client business details (from `client_context.md`)
- Tool definitions (from your DB schema → tool routes you've built)
- Voice choice (ElevenLabs voice_id — stock or cloned)
- Language(s) supported

**Steps:**

1. **Create assistant in Vapi dashboard** OR via API:
```typescript
import { VapiClient } from "@vapi-ai/server-sdk";
const vapi = new VapiClient({ token: process.env.VAPI_API_KEY });

const assistant = await vapi.assistants.create({
  name: `${clientSlug}-receptionist`,
  model: {
    provider: "anthropic",
    model: "claude-haiku-4-5-20251001",  // Haiku for realtime
    systemPrompt: SYSTEM_PROMPT,
    maxTokens: 200,  // Voice answers should be short
    temperature: 0.3,  // Lower = more consistent
    tools: TOOL_DEFINITIONS
  },
  voice: {
    provider: "11labs",
    voiceId: process.env.ELEVENLABS_VOICE_ID,
    model: "eleven_turbo_v2_5",  // or "eleven_multilingual_v2" if non-English
    stability: 0.5,
    similarityBoost: 0.75,
    optimizeStreamingLatency: 3  // 0-4; 3 is balanced
  },
  transcriber: {
    provider: "deepgram",
    model: "nova-3",
    language: clientLanguage,
    endpointing: clientLanguage === "en" ? 500 : 600
  },
  firstMessage: `Hi, this is ${persona.name}, an AI assistant for ${clientName}. How can I help you today?`,
  serverUrl: `${process.env.NEXT_PUBLIC_APP_URL}/api/voice/vapi/webhook`,
  serverUrlSecret: process.env.VAPI_WEBHOOK_SECRET,  // for signature verification
  silenceTimeoutSeconds: 30,
  responseDelaySeconds: 0.4,  // wait this long after caller stops before responding
  llmRequestDelaySeconds: 0.1,
  numWordsToInterruptAssistant: 2,  // if caller says 2+ words while bot speaks, bot stops
  endCallFunctionEnabled: true,
  endCallPhrases: ["goodbye", "bye", "thank you bye"]
});
```

2. **System prompt structure** (the order matters for prompt caching):
   - Identity + role + first AI disclosure (stable, cached)
   - Tools available + when to use each (stable, cached)
   - Business knowledge (services, prices via tool, hours, location) (stable, cached)
   - Behavior rules (confirm before booking, never invent, etc.) (stable, cached)
   - The dynamic per-call context comes via the user turn

3. **Configure webhook URL** to point to `/api/voice/vapi/webhook`:
   - Vapi sends events: `call.started`, `call.ended`, `function.called`, `transcript.partial`, `transcript.final`
   - Verify `X-Vapi-Signature` HMAC on every webhook
   - Insert/update `voice_calls` row on each event

4. **Tool definitions** matching your DB:
```typescript
const TOOL_DEFINITIONS = [
  {
    type: "function",
    function: {
      name: "check_availability",
      description: "Check available appointment slots for a given service and date range",
      parameters: {
        type: "object",
        properties: {
          service_slug: { type: "string" },
          start_date: { type: "string", description: "ISO 8601 date" },
          days_ahead: { type: "number", default: 7 }
        },
        required: ["service_slug", "start_date"]
      },
      server: {
        url: `${process.env.NEXT_PUBLIC_APP_URL}/api/voice/tools/check_availability`,
        secret: process.env.VAPI_WEBHOOK_SECRET
      }
    }
  },
  // ... book_appointment, get_services, cancel_appointment, transfer_to_human, send_whatsapp_followup, etc.
];
```

5. **Assign phone number** to the assistant via Vapi dashboard or API.

**Evidence:**
- Vapi assistant ID + the JSON config (no secrets)
- One successful test call recording + transcript
- Webhook signature verification confirmed (tampered → 401)
- All tools confirmed reachable (Vapi dashboard "Test Tool" output)

**Done condition:** Test call completes end-to-end, voice-to-voice p95 < 1000ms on the call, webhook signed + verified.

**Common mistakes:**
- `maxTokens: 1024` → answers are too long for voice, latency balloons. Use 200.
- Missing webhook signature verification → anyone with the URL can spoof Vapi events.
- Stable system prompt blocks not cached → 50-80% input token waste per turn.
- `responseDelaySeconds: 0` → bot talks over the caller. 0.4 is good for English; longer for Hindi/Tamil.
- Tool descriptions vague → LLM guesses wrong tool. Be specific in the description.
