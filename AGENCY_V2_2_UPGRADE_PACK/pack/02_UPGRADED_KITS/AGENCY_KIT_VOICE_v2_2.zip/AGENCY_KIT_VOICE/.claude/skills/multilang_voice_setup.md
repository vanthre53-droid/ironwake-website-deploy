# SKILL: multilang_voice_setup

**When to use:** Client needs >1 language support OR a non-English language. Skip if English-only.

**Reference:** Voice v2.1 Section 23 — three modes + stack per language + code-switching.

**Steps:**

1. **Pick the language mode** (Q23 in the build prompt):
   - **Single-language** — one language only; default for English-only US/UK
   - **Caller-picks** — bilingual greeting, caller selects; default for Indian SMBs
   - **Auto-detect** — agent detects from first utterance; most natural, +150-300ms first-turn latency

2. **Pick the stack per language:**

| Language | STT | TTS | Endpointing | Notes |
|----------|-----|-----|-------------|-------|
| English (US/UK/AU) | Deepgram Nova-3 | ElevenLabs Turbo v2.5 | 500ms | Lowest latency stack |
| Hindi | Deepgram Nova-3 (hi) | ElevenLabs Multilingual v2 | 600ms | Native Hindi voices available |
| Hinglish (code-switching) | Deepgram Nova-3 (multi) | ElevenLabs Multilingual v2 | 650ms | Multilingual v2 only — Turbo can't code-switch |
| Telugu / Tamil / Kannada / Bengali | Deepgram Nova-3 (multi) | ElevenLabs Multilingual v2 | 600-700ms | Quality varies; test per voice |
| Spanish (US Latino) | Deepgram Nova-3 (es) | ElevenLabs Multilingual v2 | 500ms | Solid stack |
| Spanish (LatAm) | Deepgram Nova-3 (es) | ElevenLabs Multilingual v2 + regional voice | 500ms | Pick voice by region |
| Arabic | Deepgram Nova-3 (ar) | ElevenLabs Multilingual v2 | 700ms | Longer pauses; RTL admin UI |
| Portuguese (BR) | Deepgram Nova-3 (pt) | ElevenLabs Multilingual v2 | 500ms | Standard stack |
| French | Deepgram Nova-3 (fr) | ElevenLabs Multilingual v2 | 500ms | Standard stack |

3. **Configure the greeting per mode:**

**Caller-picks:**
```
firstMessage: "Hello, namaste! Press 1 for English, या Hindi के लिए 2 दबाएं."
```
Then handle DTMF input → set conversation language → continue.

**Auto-detect:**
```
firstMessage: "" // empty; bot waits for caller to speak
```
First turn: classify language (Claude Haiku, JSON-only: `{ "lang": "en"|"hi"|... }`), then continue in that language.

4. **System prompt structure for multilingual agent:**
```
You are ${persona.name}, an AI assistant for ${clientName}.

LANGUAGE RULES:
- The caller may speak in ${listOfLanguages}.
- The caller may mix languages mid-sentence (code-switching is common in this market).
- Respond in whichever language the caller used most recently.
- Never correct the caller's language choice.
- If you don't understand, say so in the caller's primary language and offer to transfer to a human.

[rest of system prompt in English; Claude handles multilingual response generation natively]
```

5. **Per-language compliance:**
   - Hindi/regional: IT Amendment Rules 2026 SGI disclosure must be in the caller's language — pre-record disclosure per language as the first sentence
   - Spanish (US): FCC requires disclosures in the language used
   - Arabic / RTL: admin transcript display must support RTL rendering

6. **Test matrix (extend Voice v2.0 Section 12):**
   For each supported language, run:
   - Native speaker, polite
   - Native speaker, frustrated
   - Code-switching speaker (if applicable)
   - Strong accent / dialect variant

7. **Cost note:** Multilingual v2 is ~2× Turbo. Single-English agents should never use Multilingual v2.

**Evidence:**
- Stack config per supported language
- 1 test call per language with transcript + recording
- Per-language compliance (disclosure in correct language) confirmed
- Code-switching test (if applicable) — handles 5 mixed-language utterances without dropping context
- Cost per call by language (Multilingual v2 calls more expensive — track separately)

**Done condition:** Each supported language produces a call where the agent stays in the right language, doesn't refuse to engage, and meets latency budget.

**Common mistakes:**
- Using Turbo v2.5 for non-English — voice mispronounces, sounds broken
- Forgetting endpointing per language — Hindi/Tamil callers naturally pause longer; 500ms cuts them off mid-thought
- System prompt in English only when handling non-English caller — Claude is multilingual native, but explicit instruction in target language reduces "language drift" risk
- No per-language compliance disclosure — illegal in several jurisdictions
