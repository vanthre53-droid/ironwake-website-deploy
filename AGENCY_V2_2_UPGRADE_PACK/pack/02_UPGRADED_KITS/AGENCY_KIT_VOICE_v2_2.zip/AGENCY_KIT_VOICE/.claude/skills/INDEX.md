# SKILLS INDEX — Agency Kit Voice

| # | Skill | When |
|---|-------|------|
| 1 | `vapi_agent_setup` | Configuring a Vapi assistant (system prompt, tools, voice, webhook) |
| 2 | `retell_agent_setup` | Configuring a Retell agent (LLM webhook mode) |
| 3 | `voice_persona_design` | Picking + customizing a persona for the client's niche (Section 26 of v2.1) |
| 4 | `tcpa_outbound_setup` | Wiring TCPA-safe outbound (canDial, suppression, AMD) — Section 25 of v2.1 |
| 5 | `call_qa_scoring` | Setting up auto-QA (cron + scoring job + weekly report) — Section 27 of v2.1 |
| 6 | `latency_optimization` | Diagnosing + fixing voice-to-voice latency breaches |
| 7 | `multilang_voice_setup` | Multi-language stack (Section 23 of v2.1) |
| 8 | `voice_clone_consent_flow` | If using a cloned voice — consent + revocation infrastructure (Section 30 of v2.1) |

All voice skills end in evidence (latency numbers, QA scores, test call recordings, consent records).

## v2.2 additions
| 9 | `barge_in_setup` | Interruption handling — yield-on-speech, disclosure protection, backchannel (§33). Build FIRST |
| 10 | `warm_transfer_handoff` | Whisper/screen-pop context handoff + scheduled callbacks (§34) |
| 11 | `carrier_failover` | Automatic primary→backup telephony failover (§35) |
| 12 | `demo_clone_pipeline` | Config-driven prospect demo cloning via API (§39) |
