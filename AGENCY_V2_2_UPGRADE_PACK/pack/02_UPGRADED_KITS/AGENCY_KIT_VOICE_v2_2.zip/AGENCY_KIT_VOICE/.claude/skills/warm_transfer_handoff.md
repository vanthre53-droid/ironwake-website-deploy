# SKILL: warm_transfer_handoff

**When to use:** Wiring human handoff. A cold "someone will help you" transfer annoys the caller AND the client's staff.

**Reference:** Voice v2.2 Section 34 (modules/40c-VOICE_v2_2_CONSOLIDATED.md).

**Steps:**
1. Warm transfer (human available): the transfer-deciding model turn ALSO generates the 1–2 sentence handoff (who's calling + CRM match · intent + what's been done · sentiment) → delivered as whisper or screen-pop → then connect. Zero added caller-path latency.
2. No human available → scheduled callback: `scheduled_callbacks` row + same summary as context.
3. Data: `voice_calls.transfer_summary` + `transfer_type` CHECK (warm_whisper/warm_screenpop/callback_scheduled/none).

**Evidence:** a test transfer where the human hears/sees the summary BEFORE the caller connects; the row pasted.
