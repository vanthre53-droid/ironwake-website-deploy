#!/usr/bin/env bash
# Agency Kit V7 — new project bootstrap
# Usage: ./scripts/new-project.sh <project-slug> [client-name]
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <project-slug> [\"Client Name\"]"
  echo "Example: $0 sunrise-dental \"Sunrise Dental Clinic\""
  exit 1
fi

SLUG="$1"
CLIENT_NAME="${2:-$SLUG}"
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET_DIR="../${SLUG}"

if [[ -d "$TARGET_DIR" ]]; then
  echo "Error: $TARGET_DIR already exists. Aborting."
  exit 1
fi

echo "[1/8] Creating project directory: $TARGET_DIR"
mkdir -p "$TARGET_DIR"
cd "$TARGET_DIR"

echo "[2/8] Initializing Next.js 14 with TypeScript + Tailwind + App Router"
pnpm create next-app@latest . --typescript --tailwind --eslint --app --src-dir --import-alias "@/*" --use-pnpm --no-turbo

echo "[3/8] Installing core dependencies"
pnpm add @supabase/supabase-js @supabase/ssr @anthropic-ai/sdk zod @upstash/ratelimit @upstash/redis pino pino-pretty
pnpm add -D @types/node tsx vitest @vitest/ui @testing-library/react @testing-library/jest-dom playwright

echo "[4/8] Copying kit files (CLAUDE.md, rules, skills, agents, memory)"
cp "$KIT_DIR/CLAUDE.md" .
cp -r "$KIT_DIR/.claude" .
cp -r "$KIT_DIR/rules" .
cp "$KIT_DIR/settings.json" .claude/

echo "[5/8] Creating progress.md (resume protocol)"
cat > progress.md <<EOF
# PROGRESS — ${CLIENT_NAME} (${SLUG})

**Status:** scaffolded — Day 0
**Last updated:** $(date -u +"%Y-%m-%d %H:%M UTC")
**Build order:** DB → API → pages

## Completed
- [x] Step 00: Project scaffolded with Agency Kit V7

## Up next
- [ ] Step 01: Fill in client requirements (PRD)
- [ ] Step 02: Create Supabase project + .env.local
- [ ] Step 03: Design DB schema (migrations/0001_initial.sql)
- [ ] Step 04: Verification Gate A (DB)

## Blockers
- None

## Decisions log
- $(date -u +"%Y-%m-%d") — scaffolded from Agency Kit V7
EOF

echo "[6/8] Creating .env.local template (placeholder values only)"
cat > .env.local.example <<'EOF'
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# Anthropic
ANTHROPIC_API_KEY=

# Upstash (rate limiting)
UPSTASH_REDIS_REST_URL=
UPSTASH_REDIS_REST_TOKEN=

# Sentry (optional but recommended)
SENTRY_DSN=
NEXT_PUBLIC_SENTRY_DSN=

# Observability
LANGFUSE_PUBLIC_KEY=
LANGFUSE_SECRET_KEY=
LANGFUSE_HOST=https://cloud.langfuse.com
EOF
cp .env.local.example .env.local
echo ".env.local" >> .gitignore
echo ".env" >> .gitignore

echo "[7/8] Creating check-env.ts validator"
mkdir -p scripts
cat > scripts/check-env.ts <<'EOF'
import { z } from "zod";
const Env = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(20),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(20),
  ANTHROPIC_API_KEY: z.string().startsWith("sk-ant-"),
});
const parsed = Env.safeParse(process.env);
if (!parsed.success) {
  console.error("❌ ENV VALIDATION FAILED:\n", parsed.error.flatten().fieldErrors);
  process.exit(1);
}
console.log("✅ Env validated");
EOF

echo "[8/8] First commit"
git init -q
git add -A
git commit -q -m "chore: scaffold from Agency Kit V7 for ${CLIENT_NAME}"

echo ""
echo "✅ Project ready at: $TARGET_DIR"
echo ""
echo "NEXT STEPS:"
echo "  1. cd ${TARGET_DIR}"
echo "  2. Fill in .env.local with real values"
echo "  3. Open in Claude Code — it will read CLAUDE.md + progress.md automatically"
echo "  4. State the PRD; follow the 13-step plan from File 39's Phase 2"
