# VERIFICATION GATES — claims require evidence

Every phase ends with a gate. A gate is **not passed** until the listed evidence is pasted into the chat / `progress.md`. No exceptions.

---

## GATE A — DATABASE (closes Phase: schema + migrations)
Evidence required:
- `supabase db push` output showing migrations applied with no errors
- `SELECT count(*) FROM <each_seeded_table>` returning expected row counts
- `pg_dump --schema-only` snippet for each new table (column names, types, constraints, indexes)
- RLS test: `supabase test db` output showing tenant isolation passing for at least one cross-tenant access attempt
- One verifiable foreign-key constraint demonstration (insert that should fail does fail with FK error)

---

## GATE B — API ROUTES (closes Phase: server endpoints)
Evidence required:
- `curl -i` output for every public route showing: correct status code, signed/verified payloads, rate-limit headers (`X-RateLimit-*`)
- One **negative** test per route: missing auth → 401, bad signature → 403, ratelimited → 429
- Zod validation proof: invalid input → 400 with structured error
- For webhook routes: HMAC verification test (valid → 200, tampered → 401)
- For any AI route: response includes `correlationId` AND model name in headers

---

## GATE C — UI / PAGES (closes Phase: frontend)
Evidence required:
- Lighthouse mobile + desktop scores: Performance ≥90, Accessibility ≥95, Best Practices ≥95, SEO ≥95
- Screenshot of each new page on 375px (mobile) and 1440px (desktop)
- Keyboard-only navigation walkthrough: every interactive element reachable + visible focus ring
- `axe-core` automated a11y scan: zero violations on each page
- `pnpm test` output: passing component tests for any non-trivial UI logic

---

## GATE D — SECURITY (closes Phase: pre-deploy hardening)
Evidence required:
- `pnpm audit --prod` output: zero critical, zero high
- The five prompt-injection tests (see `.claude/skills/injection_test.md`) run against the AI surface — all defended
- CSP / HSTS / X-Frame-Options / X-Content-Type-Options headers verified via `curl -I https://<deploy-url>`
- Secrets scan: `gitleaks detect --source .` returns clean
- Server-side env audit: `grep -r "NEXT_PUBLIC_" src/ | grep -E "(KEY|SECRET|TOKEN)"` returns empty
- Webhook signature verification proven on a tampered payload (must reject)

---

## GATE E — DEPLOY + OBSERVABILITY (closes Phase: ship)
Evidence required:
- Production URL responding 200 to `/api/health`
- Sentry receiving events (manual test error → visible in Sentry within 2 min)
- Langfuse receiving traces (one AI call → visible trace with full span tree)
- One end-to-end happy-path executed in production with screenshots
- `docs/RUNBOOKS.md` updated: "what to do if X breaks" for each integration
- `docs/COSTS.md` updated with first 24h observed costs (Anthropic, Supabase, Vercel, etc.)
- Tag the deploy: `git tag v0.1.0 && git push --tags`

---

## ENFORCEMENT
- Skip a gate → next session starts by closing it before any new work
- Gate fails on a re-check → revert the change that broke it, fix, re-run the gate
- "Lighthouse 88" is not "Lighthouse 90+" — round-up is not a verification strategy
- Cherry-picking evidence (running tests until they pass once, ignoring intermittent failures) is a P0 integrity issue
