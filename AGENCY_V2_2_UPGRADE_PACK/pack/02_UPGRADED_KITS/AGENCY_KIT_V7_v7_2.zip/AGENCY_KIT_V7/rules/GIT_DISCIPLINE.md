# GIT DISCIPLINE

## Commit format (Conventional Commits)
```
<type>(<scope>): <subject>

<body — what changed and why, not how>

<optional: trailer e.g. "Closes Gate A: DB schema verified — see progress.md">
```

**Types:** `feat` (user-visible feature) · `fix` (bug fix) · `chore` (housekeeping, deps) · `docs` · `refactor` (no behavior change) · `test` · `perf` · `ci` · `revert`

## Rules
1. **One logical change per commit.** If your commit message contains "and", reconsider.
2. **No `git push --force` to `main`** (or any shared branch). Force-pushing rewrites history others depend on.
3. **Commit at gate boundaries.** Every Verification Gate that passes earns its own commit with the gate name in the trailer.
4. **No commits with broken builds.** Run `pnpm build` before commit. If `package.json` changed, run `pnpm install` and commit `pnpm-lock.yaml` together.
5. **No commits with failing tests.** `pnpm test` clean before commit. If you intentionally skip a test, add `// TODO: ...` and an issue.
6. **No secrets, ever.** If you accidentally commit a secret, rotate immediately (don't just `git rm`), then `git filter-repo` or use BFG to remove from history.
7. **`.gitignore` is not optional.** `node_modules`, `.next`, `.env*` (except `.env.example`), `.DS_Store`, `coverage/`, `playwright-report/`.

## Branch strategy (single dev / small team)
- `main` — always deployable; protected branch
- `feat/<short-description>` — one feature
- `fix/<short-description>` — one fix
- Branches live <3 days. Merge fast or close. Long-lived branches accumulate drift.

## PR conventions
- Title = commit subject of the final squash
- Body answers: **what** changed, **why**, **how to verify**
- Link gate evidence in the body (Lighthouse JSON, curl output, etc.)
- One reviewer; reviewer's job is to confirm gates passed and the change matches what was promised in the PR description

## When something goes wrong
- Bad commit on a feature branch → `git commit --amend` or interactive rebase before pushing
- Bad commit pushed to `main` → `git revert <sha>` and push the revert (never force-push to undo)
- Forgot to branch and committed to `main` → `git branch feat/x && git reset --hard origin/main && git checkout feat/x`

## Tag releases
- Semantic versioning: `v<major>.<minor>.<patch>`
- Tag at every Gate E pass
- `git tag -a v0.1.0 -m "First production deploy" && git push --tags`
