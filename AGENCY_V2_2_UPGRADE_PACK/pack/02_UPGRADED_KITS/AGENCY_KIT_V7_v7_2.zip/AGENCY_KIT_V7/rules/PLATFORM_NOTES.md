# PLATFORM NOTES — how each AI dev tool uses this kit

## Claude Code (primary target)
- Reads `CLAUDE.md` automatically on session start
- Reads `.claude/settings.json` for permissions, model routing, branch protection
- Loads skills from `.claude/skills/*.md` — invoke by name
- Loads agents from `.claude/agents/*.md`
- Reads `.claude/memory/*.md` for cross-session context
- **First action every session:** open `progress.md` (already configured in settings)

## Cursor
- Copy `CLAUDE.md` contents into `.cursorrules` (or create a symlink: `ln -s CLAUDE.md .cursorrules`)
- Cursor reads `.cursorrules` on every Composer/Chat request
- Skills become **per-feature prompt cards** — open Composer per skill, paste skill content + the specific feature ask
- Agents become Cursor's `@docs` references — paste agent definition before invoking
- Memory: paste relevant `.claude/memory/*.md` content at session start
- The `settings.json` modelRouting block is informational — Cursor uses its own model selector

## Replit Agent
- Paste `CLAUDE.md` into Replit's "Custom Instructions" panel
- Replit auto-handles deploy + env vars (use Replit Secrets, skip the local `.env.local` flow)
- Skip parts of skills that assume local CLI access — Replit shell has limits
- Use Replit's checkpoint/rollback instead of `git commit` per step (still tag releases on milestones)

## Bolt / v0 / Lovable (frontend-first)
- These tools can't run the full kit. Use them ONLY for the frontend layer.
- Extract the UI/UX section of `CLAUDE.md` and Section 04 of the build prompt — paste those
- Backend (DB, API, auth, RLS, AI) gets built separately in Claude Code or Cursor
- Hand off in two passes: Bolt builds UI → Claude Code wires backend → both meet in a verification step

## Generic LLM chat (ChatGPT, Claude.ai web, Gemini, etc.)
- Paste `CLAUDE.md` as the first message of every session
- Paste `progress.md` next
- Paste the specific skill or rule file relevant to the task
- No file system access — they can guide, you execute commands manually

## What stays constant across all platforms
- The 5 absolute rules in `CLAUDE.md` §2
- The Verification Gates (`rules/VERIFICATION_GATES.md`)
- The security baseline (`rules/SECURITY_BASELINE.md`)
- The DB → API → pages build order

What changes is just the **delivery format** — the underlying spec is identical.
