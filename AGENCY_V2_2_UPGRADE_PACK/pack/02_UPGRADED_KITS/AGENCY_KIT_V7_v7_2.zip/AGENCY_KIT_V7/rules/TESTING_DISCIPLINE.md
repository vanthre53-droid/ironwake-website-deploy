# TESTING DISCIPLINE

## §1. What gets tested (and what doesn't)
**Tested:**
- Every API route — happy path + 1 negative path
- Every Zod schema — at least one valid + one invalid input
- Every business-logic function with branching (more than `if/return`)
- Every AI tool function — mocked Claude response + real input shape
- Every webhook handler — valid signature + tampered signature

**Not tested (intentionally):**
- Trivial getters/setters
- Generated code (Supabase types, shadcn components)
- One-line utility functions with obvious behavior
- React components without conditional logic

## §2. Test stack
- **Unit + integration:** Vitest
- **Component:** Vitest + Testing Library
- **E2E:** Playwright (one happy-path smoke per major user journey)
- **DB / RLS:** `supabase test db` with pgTAP-style assertions
- **AI:** snapshot the prompt + a fixed fixture response; assert post-processing behavior

## §3. Test naming
```
describe('<unit under test>', () => {
  it('returns X when given Y', () => { ... })
  it('throws Z when given invalid input', () => { ... })
})
```
- Sentence-style `it` descriptions: future you reading test failures should understand what broke without opening the test code
- Group by behavior, not by implementation detail

## §4. The eval harness (AI features)
Every AI feature has an eval harness in `evals/<feature>.test.ts`:
- A fixed set of N real scenarios (10–50)
- Expected outcomes per scenario (booked / answered / escalated / refused)
- Runs on every CI build
- Threshold: ≥90% pass = green; <90% = block deploy

The eval harness is the AI feature's Verification Gate. Prompts get changed often; the harness catches regressions you'd otherwise notice in production a week later.

## §5. Coverage targets (not vanity metrics)
- Aim for **meaningful coverage of branches**, not line coverage percentages
- 100% line coverage with no assertions is worthless
- 60% line coverage with the right paths tested is fine
- Don't chase coverage badges; chase confidence

## §6. Flaky tests
- Flaky test = broken test
- A flaky test that "passes most of the time" hides real failures
- Fix or delete. No `it.skip` permanent quarantine.

## §7. CI
- Every PR runs: lint + type-check + unit/integration + smoke E2E + audit + build
- Red CI blocks merge (branch protection)
- "It works on my machine" is not evidence; CI is

## §8. Before any commit that adds/changes a route
1. Add the test for the new behavior
2. Run the test — confirm it fails the way you expect
3. Implement the route
4. Run — confirm it passes
5. Run the full test suite — confirm nothing else broke
6. Commit code + test together
