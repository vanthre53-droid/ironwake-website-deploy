# SECURITY BASELINE — non-negotiable for every project

## §1. The baseline (every project, opt-out requires written exception)
1. **Row Level Security (RLS) ON for every tenant table.** Tested. A user in tenant A cannot read or write tenant B's rows. Proven by `supabase test db`.
2. **Webhook signature verification on every external webhook.** Stripe, WhatsApp, Vapi, Retell, any external POST → verify HMAC/RSA before processing the body. Tampered body → 401 + log.
3. **Rate limiting on every public + auth endpoint.** `@upstash/ratelimit` with sliding window. Headers exposed: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`.
4. **Server-only secret access.** No `NEXT_PUBLIC_*` for keys. Run `grep -r "NEXT_PUBLIC_" src/ | grep -iE "(KEY|SECRET|TOKEN|PASS)"` — must return empty.
5. **Headers in `middleware.ts`:** CSP (with nonces if you use inline scripts), HSTS, X-Frame-Options DENY, X-Content-Type-Options nosniff, Referrer-Policy strict-origin-when-cross-origin, Permissions-Policy (deny camera/mic/geolocation unless used).
6. **Input validation everywhere.** Every API route uses Zod schemas at the boundary. Reject malformed input with 400 + structured error (no stack traces in prod responses).
7. **AI surface hardened.** Treat ALL user input as data, never as instructions. The five injection tests in `.claude/skills/injection_test.md` must pass before any AI route ships.
8. **No exec / shell injection paths.** No `child_process.exec(userInput)`. Use `execFile` with arg arrays or, better, library calls.
9. **Idempotency on payments + bookings.** Same `Idempotency-Key` header → same response. Webhook replays don't double-charge or double-book.
10. **Auth: HttpOnly + Secure + SameSite=Lax cookies.** Session tokens never readable from JS.

## §2. Known CVEs to actively avoid (June 2026)
- **CVE-2025-29927 (Next.js middleware bypass)** — affects Next.js <14.2.25 and <15.2.3. Always pin a patched version.
- **MCPoison / IDE config injection** — never auto-trust `.mcp.json` or similar config from cloned repos; review before running.
- **Prompt injection via uploaded files / images** — if your app accepts user uploads that get sent to Claude, strip metadata + sandbox: never pass uploaded files to a system prompt or tool that has access to other users' data.

## §3. Niche-specific overlays (add to baseline; do not subtract)

### Healthcare / dental
- PHI never logged to Sentry, Langfuse, or `console.log`
- Vendor BAA required: Supabase BAA (Team plan+), Anthropic Zero-Data-Retention (enterprise tier), Vapi/Retell BAA where available
- Audit log for every PHI access (`audit_logs` table)
- AES-256 at rest, TLS 1.3 in transit (Supabase + Vercel both do this by default — verify, don't assume)

### Payments / e-commerce
- Card data never touches your servers; tokenized via Stripe/Razorpay
- Idempotency keys required on POST /payments
- PCI: out of scope by virtue of using a tokenizing processor — but only if you never log card numbers or CVV (`grep` your logs in prod for `\\d{16}` regex)

### Law
- Privilege protection: no conversation data shared across tenants (RLS proves it)
- "Not legal advice" disclaimer on every AI output where the user asks a legal question — bot must refuse to give legal advice, only intake info

### Real estate (US)
- Fair Housing Act language scanning: AI output filtered for protected-class references (race, color, national origin, religion, sex, familial status, disability) in housing context
- Equal Credit Opportunity Act: don't ask or store info on protected classes during qualification

## §4. Pre-deploy security checklist (Gate D)
- [ ] `pnpm audit --prod`: 0 critical, 0 high
- [ ] `gitleaks detect`: clean
- [ ] `grep -r "NEXT_PUBLIC_.*\\(KEY\\|SECRET\\|TOKEN\\)"`: empty
- [ ] RLS test passes
- [ ] Webhook signature test passes (valid → 200, tampered → 401)
- [ ] Rate-limit test passes (101st request inside window → 429)
- [ ] Five injection tests defended
- [ ] Headers verified via `curl -I` against deployed URL

## §5. Incident response
- Suspected breach → rotate ALL credentials in Infisical, invalidate sessions, freeze production deploys, audit logs for the window
- Don't "investigate quietly" — assume breach, contain first
- Notify client within 4 hours of confirmed breach (contractual + ethical requirement)

## §6. What this baseline is NOT
This is the **floor**. It is not "military-grade", "bank-grade", "enterprise-grade", or any other adjective. It's the minimum to ship a non-embarrassing production product. Never use marketing adjectives for security in a client document — write the specific control instead.
