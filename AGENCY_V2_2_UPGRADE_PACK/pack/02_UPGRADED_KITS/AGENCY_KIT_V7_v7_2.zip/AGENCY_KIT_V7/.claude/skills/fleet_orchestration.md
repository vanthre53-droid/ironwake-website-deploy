# SKILL: fleet_orchestration

**When to use:** Building or extending the multi-agent AI-employee layer (2+ coordinating agents), or the single-agent carve-out for client #1. Gate-heavy — every phase pastes evidence.

**Reference:** v7.2 Section 33 (modules/39c-V7_2_UPGRADE_MODULE.md) + T1_02 phases F1–F8.

**Steps:**
1. Enforce the T1_02 §0 decision: paying client with ≥3 agents / own Command Center / neither → neither = STOP, build the §7 carve-out instead.
2. F1 substrate [GLM]: `agent_tasks` (§33.1 envelope + state machine CHECK), `knowledge_chunks`+`entities` (§33.4), `fleet_budget` (§33.6), dedup table (§33.8). RLS on; `tenant_isolation_test`.
3. F2 governance [Opus]: transition enforcer, idempotency guard, cost governor + kill-switch.
4. F3 Planner [Opus] (§33.2): machine-checkable acceptance on every task; never invents agents; unmappable → needs_human.
5. F4 workers [GLM]: one §27 agent at a time, each passes its eval harness.
6. F5 Critic [Opus rubric] (§33.3): ≥80 pass · defect-list return · 2-fail → needs_human · no loops.
7. F7 grounding freshness (§33.5) — build even solo. F8 observability + prompt registry (§33.8).

**Evidence:** illegal transition rejected · duplicate trigger_key refused · kill-switch pauses admission · Planner graph with valid owners · Critic pass/fail/escalate triple · stale price re-grounded before answer.
