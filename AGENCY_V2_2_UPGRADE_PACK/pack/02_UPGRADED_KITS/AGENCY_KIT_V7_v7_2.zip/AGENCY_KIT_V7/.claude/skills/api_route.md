# SKILL: api_route

**When to use:** Creating any new server endpoint — REST handler, server action, webhook, AI tool route.

**Inputs:**
- Route path (`/api/<resource>/<action>`)
- HTTP method
- Auth requirement (public | authenticated | admin | webhook-signed)
- Request schema (Zod)
- Response shape

**Steps:**
1. Create `src/app/api/<path>/route.ts`
2. Import: Zod schema, Supabase server client, logger, rate-limit helper
3. Body skeleton:
   - Generate `correlationId = crypto.randomUUID()`
   - Rate-limit check (public + auth routes; skip for internal cron) → 429 if exceeded
   - Auth check appropriate to route type → 401/403 if failed
   - For webhooks: verify signature against raw body BEFORE JSON parsing → 401 if invalid
   - Parse + validate body via Zod → 400 if invalid (return `.flatten()` errors, no stack)
   - Business logic in a try/catch
   - Structured logging with `correlationId` on every log line
   - Response: include `correlationId` header for traceability
4. Error responses follow this shape: `{ error: { code: string, message: string, details?: unknown }, correlationId }`
5. Never include stack traces in prod responses (NODE_ENV check)
6. Set appropriate cache headers (`no-store` for mutations + auth-scoped reads; aggressive caching only for truly public reads)

**Tests (add same commit):**
- Happy path with valid input → 2xx + expected shape
- Invalid input (Zod) → 400
- Missing auth → 401 (if auth required)
- Tampered signature → 401 (if webhook)
- Rate-limit boundary → 429 (if rate-limited)

**Evidence (paste into chat — Gate B for this route):**
- `curl -i` against happy path showing 2xx + headers
- `curl -i` against negative path showing 4xx + structured error
- Test output: route's tests all pass
- For AI routes: response includes model name + `correlationId` headers
- For webhooks: HMAC test (valid → 200, tampered → 401)

**Done condition:** Route works, tests pass, evidence pasted, committed.

**Anti-patterns to avoid:**
- Returning the raw exception message in production → leaks internals
- Logging the full request body when it contains PHI/PII → log only sanitized fields + correlationId
- Skipping rate-limit "because the route isn't critical" → critical routes don't announce themselves
- Validating after the side effect (`db.insert(...)` before Zod) → corrupt data sneaks in
- Trusting `Authorization` header without verifying — verify with the Supabase client server-side
