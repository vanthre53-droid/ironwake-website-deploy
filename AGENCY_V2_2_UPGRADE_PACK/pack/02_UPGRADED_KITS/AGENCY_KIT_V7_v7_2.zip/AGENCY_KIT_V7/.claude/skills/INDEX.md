# SKILLS INDEX — Agency Kit V7

Skills are reusable runbooks. Each ends in verifiable evidence. Invoke by name.

| # | Skill | When to use |
|---|-------|-------------|
| 1 | `scaffold_nextjs` | New project — Next.js + TypeScript + Tailwind + Supabase + shadcn |
| 2 | `db_migration` | Adding/changing a Supabase table; always Gate-A-evidence at the end |
| 3 | `api_route` | Building a new API route; always Gate-B-evidence at the end |
| 4 | `page_build` | Building a new page/feature UI; always Gate-C-evidence at the end |
| 5 | `injection_test` | Hardening any AI-touching endpoint; runs the 5-test suite |
| 6 | `prompt_cache_setup` | Wiring `cache_control` on system prompts and shared context |
| 7 | `deploy_to_vercel` | First deploy; sets up env, domains, edge config; Gate-E-evidence |
| 8 | `tenant_isolation_test` | Multi-tenant build — proves RLS works under cross-tenant attempt |

Each skill is self-contained (one .md file) and includes:
- Trigger (when to use)
- Inputs (what you need)
- Steps (numbered, evidence-emitting)
- Outputs (the evidence)
- Done condition (what "complete" looks like)

## v7.2 additions
| 9 | `fleet_orchestration` | Multi-agent fleet layer (v7.2 §33) or the single-agent carve-out — planner, critic, state machine, budget |
| 10 | `grounding_freshness` | Freshness cron + stale-block so agents never quote stale facts (v7.2 §33.5) — every agent project |
| 11 | `script_generator` | The X_01 engine: 7-point market analysis → grounded scripts for any channel |
| 12 | `webchat_widget_build` | Embeddable RAG chat widget, the 4th product surface (v7.2 §34) |
