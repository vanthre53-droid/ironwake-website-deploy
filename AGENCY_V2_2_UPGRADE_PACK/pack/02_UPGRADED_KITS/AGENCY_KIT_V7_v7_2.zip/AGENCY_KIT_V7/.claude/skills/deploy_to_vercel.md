# SKILL: deploy_to_vercel

**When to use:** First production deploy + every subsequent significant release.

**Inputs:**
- Production domain (or subdomain)
- All env vars from `.env.local` (real values, not placeholders)
- DNS access (if custom domain)

**Steps:**

## First-time setup
1. `vercel login`
2. `vercel link` — pick or create project
3. In Vercel dashboard or via CLI: set environment variables for `Production` env:
   - Every var from `.env.local.example` with the real production value
   - Mark sensitive vars (API keys, service role keys) as "Sensitive" (encrypted at rest, not visible after save)
4. Set environment variables for `Preview` env (separate from production — staging Supabase, staging Stripe, etc.)
5. Configure project settings:
   - Node.js version: 20.x
   - Build command: `pnpm build`
   - Install command: `pnpm install --frozen-lockfile`
   - Framework preset: Next.js
6. Connect Git: every push to `main` → production deploy; every PR → preview deploy
7. Custom domain: `vercel domains add <domain>` → follow DNS instructions
8. Enable Vercel Web Analytics + Speed Insights (free tier)
9. Set up branch protection on `main` (in GitHub/GitLab): require PR + CI pass

## Pre-deploy checklist
- [ ] All Verification Gates A–D passed for the changes being deployed
- [ ] `pnpm build` succeeds locally with production env
- [ ] `pnpm audit --prod`: 0 critical, 0 high
- [ ] No `console.log` of sensitive data in code (search for `console.log`, `logger.info` of user data)
- [ ] Sentry DSN configured and tested
- [ ] CSP headers configured (and not too restrictive — preview deploy first)
- [ ] Database migrations applied to production Supabase BEFORE the code deploy
- [ ] Webhook URLs updated in external services (Stripe, WhatsApp, Vapi) to point to the new domain
- [ ] DNS / SSL cert verified

## Deploy
- Push to `main` (after PR merge) → Vercel auto-deploys
- Watch the build log
- After deploy, run smoke tests against production URL

## Post-deploy verification (Gate E)
- [ ] `curl https://<domain>/api/health` → 200
- [ ] `curl -I https://<domain>` → security headers present
- [ ] Sentry: trigger a test error, confirm visible in Sentry within 2 min
- [ ] Langfuse: trigger an AI call, confirm trace visible
- [ ] One end-to-end happy-path walked through manually with screenshots
- [ ] Lighthouse against production URL: scores hold up
- [ ] Webhook providers (Stripe etc.) test events deliver successfully

## Rollback
- If Gate E fails: `vercel rollback` in the dashboard returns to previous deploy
- DB migrations: rollback requires a reverse migration — never roll back DB changes by hand on production
- Communicate to client immediately: "issue detected, rolled back to previous version, investigating"

**Evidence (Gate E):**
- Production URL responding 200
- Sentry/Langfuse screenshots of received events
- Lighthouse score on production URL
- `git tag v0.1.0` pushed
- `docs/RUNBOOKS.md` updated with the on-call info for this deploy
- `docs/COSTS.md` updated with first 24h observed costs

**Done condition:** Production live, observability working, evidence captured, client notified, tag pushed.
