# SKILL: scaffold_nextjs

**When to use:** Brand-new project. Day 0. Before any business code is written.

**Inputs:**
- Project slug (kebab-case)
- Client name
- Optional: existing Supabase project URL (if reusing)

**Steps:**
1. `pnpm create next-app@latest <slug> --typescript --tailwind --eslint --app --src-dir --import-alias "@/*" --use-pnpm`
2. `cd <slug>`
3. Install core deps: `pnpm add @supabase/supabase-js @supabase/ssr @anthropic-ai/sdk zod @upstash/ratelimit @upstash/redis pino pino-pretty`
4. Install dev deps: `pnpm add -D @types/node tsx vitest @vitest/ui @testing-library/react @testing-library/jest-dom playwright`
5. Initialize shadcn/ui: `pnpm dlx shadcn@latest init -d` (defaults: New York style, slate base, CSS variables)
6. Add core shadcn components: `pnpm dlx shadcn@latest add button input card form dialog toast table dropdown-menu`
7. Copy this kit's files: `cp -r <kit-path>/{CLAUDE.md,rules,.claude} .`
8. Create `progress.md` from `.claude/memory/progress.template.md`
9. Create `client_context.md` from `.claude/memory/client_context.template.md` (in repo root, fill in)
10. Create `.env.local` from `.env.local.example`
11. Create `scripts/check-env.ts` (validates env via Zod)
12. Add `"check-env": "tsx scripts/check-env.ts"` to package.json scripts
13. Configure `middleware.ts` with the security headers (CSP, HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy)
14. `git init && git add -A && git commit -m "chore: scaffold from Agency Kit V7"`

**Evidence (paste into chat):**
- `tree -L 2 -I 'node_modules|.next'` showing the structure
- `pnpm build` output: succeeds with 0 errors
- `pnpm check-env` output: ✅ Env validated
- `curl -I http://localhost:3000` showing security headers
- `git log --oneline` showing the scaffold commit

**Done condition:** `pnpm dev` serves the app on :3000 with security headers in place, all env validated, first commit landed.
