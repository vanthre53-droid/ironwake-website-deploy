# SKILL: webchat_widget_build

**When to use:** Any embeddable site chatbot — the 4th product surface (P1–P4 demos, client sites).

**Reference:** v7.2 Section 34 (modules/39c-V7_2_UPGRADE_MODULE.md).

**Steps:**
1. DB: chunks/entities/leads/conversations → ingest script (KB → embeddings, pgvector).
2. Streaming chat route (Vercel AI SDK): Haiku intent · Sonnet/GLM grounded answers ONLY from retrieved chunks + entities.
3. `widget.js`: shadow DOM, async, <50KB gz, config via data-tenant/accent/name/greeting/logo (the personalization pipeline rewrites these — never hardcode).
4. Disclosure header + first message · lead row on every conversation · escalation captures contact+context.
5. Public route: rate-limited, CORS-locked, 5 injection tests pass.

**Evidence:** grounded answer citing chunk · absent-fact fallback verbatim · lead row from non-converting chat · 5/5 injection · host Lighthouse ≥90.
