# SKILL: prompt_cache_setup

**When to use:** Wiring `cache_control` on every Anthropic API call that reuses content across requests. Mandatory by Day 2 of any AI project — savings are 50-90% on input tokens for the cached portions.

**What gets cached:**
- System prompt (always — it's stable across a session)
- Long context blocks (RAG retrievals, tool definitions, agent personas) reused across turns
- Few-shot examples in classification prompts
- Tool definitions when calling the same tool set across turns

**What does NOT get cached:**
- User turn content (changes every turn)
- Per-request variable content
- Cache-once-then-discarded content (analysis runs, single-shot extractions)

**How to wire:**

```typescript
import Anthropic from "@anthropic-ai/sdk";
const anthropic = new Anthropic();

const response = await anthropic.messages.create({
  model: "claude-sonnet-4-6",
  max_tokens: 1024,
  system: [
    {
      type: "text",
      text: SYSTEM_PROMPT,  // long, stable
      cache_control: { type: "ephemeral" }
    },
    {
      type: "text",
      text: AGENT_PERSONA_BLOCK,  // also stable per session
      cache_control: { type: "ephemeral" }
    }
  ],
  messages: [
    { role: "user", content: userTurn }
  ],
  tools: TOOL_DEFINITIONS  // cache by referencing in the right block — see docs
});
```

**Verification:**
After making a call, check the response usage object:
```
{
  cache_creation_input_tokens: 4523,  // first call (creates cache)
  cache_read_input_tokens: 0,
  input_tokens: 12
}
```
Next call with same cached blocks:
```
{
  cache_creation_input_tokens: 0,
  cache_read_input_tokens: 4523,  // cache hit! 90% cheaper
  input_tokens: 14
}
```

**Steps:**
1. Identify the long, stable content in your system prompt + context
2. Wrap each stable block with `cache_control: { type: "ephemeral" }`
3. Order: cached blocks BEFORE variable blocks (cache hits depend on prefix match)
4. Make two identical calls back-to-back; second should show `cache_read_input_tokens > 0`
5. Add a Langfuse trace property `cache_hit: true/false` based on `cache_read_input_tokens > 0`

**Evidence:**
- Code snippet showing `cache_control` placement
- Two API call responses pasted side-by-side: first shows `cache_creation`, second shows `cache_read`
- Langfuse dashboard screenshot showing cache hit rate >70% after 50+ calls (steady-state)

**Cost expectation:**
At steady state with proper caching, AI cost per voice call or WhatsApp conversation drops by 50–80% vs uncached. If you're not seeing this, caching is broken — debug before scaling.

**Gotchas:**
- Cache TTL is ~5 minutes by default. For longer sessions, refresh by re-sending the same cached block (counts as cache hit, keeps it alive).
- Minimum cached block size: 1024 tokens for Sonnet/Opus, 2048 for Haiku. Below that, no caching.
- Tool definitions cache as part of the request structure — don't change tool order between calls or you bust the cache.
