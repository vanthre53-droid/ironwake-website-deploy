# SKILL: db_migration

**When to use:** Adding or changing a Supabase table, view, function, or policy. Always.

**Inputs:**
- Table/object name
- Schema spec (columns, types, constraints, indexes, RLS intent)
- Tenant column? (yes for multi-tenant; column always named `tenant_id UUID NOT NULL`)

**Steps:**
1. `supabase migration new <descriptive_name>` (e.g. `add_contacts_table`)
2. Edit the generated `supabase/migrations/<timestamp>_<name>.sql`:
   - `CREATE TABLE` with explicit types (no implicit defaults)
   - `PRIMARY KEY` always UUID with `gen_random_uuid()` default
   - `created_at TIMESTAMPTZ NOT NULL DEFAULT now()` on every table
   - `updated_at TIMESTAMPTZ NOT NULL DEFAULT now()` + trigger if rows mutate
   - All FKs with `ON DELETE` behavior explicit (CASCADE | SET NULL | RESTRICT)
   - Indexes for every FK + every column used in WHERE/ORDER BY
   - `CHECK` constraints for enums (`status TEXT NOT NULL CHECK (status IN ('a', 'b', 'c'))`)
3. Add RLS policies:
   - `ALTER TABLE <name> ENABLE ROW LEVEL SECURITY;`
   - Per-tenant: `CREATE POLICY tenant_isolation ON <name> FOR ALL TO authenticated USING (tenant_id = (auth.jwt() ->> 'tenant_id')::uuid);`
   - Per-owner: `CREATE POLICY owner_access ON <name> FOR ALL TO authenticated USING (user_id = auth.uid());`
4. Apply locally: `supabase db reset` (rebuilds from migrations)
5. Test with `supabase test db` — write at least one positive + one negative RLS test
6. Generate TypeScript types: `supabase gen types typescript --local > src/lib/supabase/database.types.ts`
7. Apply to remote: `supabase db push`

**Evidence (paste into chat — this is Gate A):**
- The migration SQL (full file)
- `supabase db reset` output: success
- `supabase test db` output: passing
- `psql ... -c "\\d <table>"` showing the table definition with constraints + indexes
- A cross-tenant access attempt that fails with RLS error (proof tenant isolation works)
- Generated types file diff (showing the new types)

**Done condition:** Migration applied locally + remotely, types regenerated, RLS proven by test, committed.

**Common mistakes to avoid:**
- Missing `ENABLE ROW LEVEL SECURITY` — table is wide open by default once a policy exists
- `USING` policy without a matching `WITH CHECK` policy on INSERT/UPDATE (read works, write doesn't)
- Forgetting indexes on FK columns — JOINs become full scans
- `timestamp without time zone` instead of `timestamptz` — DST/timezone bugs in production
