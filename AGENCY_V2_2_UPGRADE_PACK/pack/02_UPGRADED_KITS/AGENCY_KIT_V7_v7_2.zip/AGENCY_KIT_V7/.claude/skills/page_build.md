# SKILL: page_build

**When to use:** Building a new page or feature UI. After DB + API for that feature exist.

**Inputs:**
- Page route (`/path`)
- Auth requirement (public | authenticated | admin)
- Data dependencies (which API routes / server actions it calls)
- Design intent (refer to `client_context.md` brand voice + colors)

**Steps:**
1. Create `src/app/<route>/page.tsx`
2. Decide Server Component vs Client Component:
   - Default: Server Component (data fetched server-side, smaller bundle)
   - Client: only for interactive state, browser APIs, or 3rd-party widgets needing window
3. For Server Components: fetch data via Supabase server client (with the user's RLS-scoped session)
4. For Client Components: fetch via the API route (which itself goes through RLS)
5. Layout: use Tailwind + shadcn primitives. No raw HTML for buttons/inputs — always shadcn.
6. Responsive: mobile-first. Test at 375px, 768px, 1024px, 1440px.
7. Loading states: every async boundary has a `loading.tsx` or inline skeleton (shadcn `Skeleton`)
8. Error states: every async boundary has `error.tsx` with a user-friendly message + retry
9. Empty states: when data is empty, show an instructive illustration + CTA (not just "No data.")
10. A11y: every `<img>` has alt, every `<button>` has accessible label, focus order is logical, keyboard-only path works
11. Form patterns: shadcn `Form` + `react-hook-form` + Zod resolver (same schema as the API route's)
12. Toast feedback on every mutation (success + error)

**Tests:**
- Component test for any non-trivial conditional rendering
- Playwright smoke for the happy path

**Evidence (Gate C):**
- Lighthouse mobile + desktop: Perf ≥90, A11y ≥95, BP ≥95, SEO ≥95 (paste full scores)
- Screenshots at 375px and 1440px
- `axe-core` scan: 0 violations
- Keyboard walkthrough description (every interactive element reachable)
- Component test output: passing

**Done condition:** Page works, scores hit, evidence pasted, committed.

**Anti-patterns to avoid:**
- Using `useEffect` to fetch data in Server-Component-capable pages (defeats the streaming/SEO benefit)
- Hard-coded copy that should come from `client_context.md` (then it's reusable across projects)
- Custom CSS for things Tailwind already does (consistency loss, bundle bloat)
- Missing the empty state (real users hit empty states before they hit populated ones)
- Skipping mobile testing because "everyone uses desktop" — they don't
