# SKILL: script_generator

**When to use:** Any script — agent lines, bot copy, templates, cold DM/email, human sales pitch. Never write lines directly.

**Reference:** X_01_SCRIPT_GENERATOR_ENGINE.md (+ V_05/W_05/T1_05 channel adapters).

**Steps:**
1. REFUSE RULE: no output until the 7-finding analysis pass is stated AND a grounded source is provided. Missing → ask.
2. Run §2: buyer emotional state · objection ladder to the ROOT · incumbent + winning axis · market calibration · channel physics · compliance overlay · one-CTA conversion spine.
3. Route through the §3 channel adapter (voice ≤200 tokens/turn; WhatsApp templates = separate per-language artifact; DM brutally short).
4. Emit requested outputs: A agent script (disclosure/grounding/escalation/confirm wired) · B human sales script (pain-first, preview-first demo line, owner objections, close = outcome + price + parent as signing entity) · C artifacts.

**Evidence:** the 7 findings block precedes the script; §5 quality-gate checklist all ticked.
