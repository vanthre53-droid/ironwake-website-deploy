# SKILL: tenant_isolation_test

**When to use:** Any multi-tenant build (agency managing multiple clients on one codebase). Before any production traffic. Whenever a new tenant table is added.

**The threat being defended:** User A (tenant Alpha) reads, modifies, or deletes data belonging to User B (tenant Beta). Even when there's a bug in your API code. RLS is the last line of defense.

**Steps:**

1. **Seed two tenants with distinct data:**
```sql
-- Tenant Alpha
INSERT INTO tenants (id, name, slug) VALUES ('00000000-0000-0000-0000-00000000000a', 'Alpha Clinic', 'alpha');
INSERT INTO contacts (tenant_id, phone, name) VALUES ('00000000-0000-0000-0000-00000000000a', '+15550001', 'Alpha Contact 1');

-- Tenant Beta
INSERT INTO tenants (id, name, slug) VALUES ('00000000-0000-0000-0000-00000000000b', 'Beta Clinic', 'beta');
INSERT INTO contacts (tenant_id, phone, name) VALUES ('00000000-0000-0000-0000-00000000000b', '+15550002', 'Beta Contact 1');
```

2. **Create test JWTs for users in each tenant.** Supabase: sign in as a user mapped to Alpha tenant, capture the JWT. Repeat for Beta.

3. **Run cross-tenant read tests via the Supabase client (with the JWT, so RLS is in effect):**

```typescript
// As Alpha user, read all contacts
const { data: alphaData } = await alphaClient.from('contacts').select('*');
// Expected: only Alpha Contact 1, NO Beta data
assert(alphaData.length === 1);
assert(alphaData[0].tenant_id === ALPHA_TENANT_ID);

// As Alpha user, try to read Beta's contact by ID
const { data: stolenData, error } = await alphaClient
  .from('contacts')
  .select('*')
  .eq('id', betaContactId);
// Expected: empty array + no error (RLS silently filters; not a 403)
assert(stolenData.length === 0);
```

4. **Run cross-tenant write tests:**
```typescript
// As Alpha user, try to INSERT a contact with Beta's tenant_id
const { error: insertError } = await alphaClient
  .from('contacts')
  .insert({ tenant_id: BETA_TENANT_ID, phone: '+15559999' });
// Expected: error from WITH CHECK policy (or empty result if policy is permissive on insert)

// As Alpha user, try to UPDATE Beta's contact
const { data: updateData, error: updateError } = await alphaClient
  .from('contacts')
  .update({ name: 'Hacked' })
  .eq('id', betaContactId);
// Expected: empty update result (RLS filters the row out of the UPDATE scope)
// Then verify Beta's contact still has original name from Beta's perspective
```

5. **Run as anonymous (no JWT):**
```typescript
const { data: anonData } = await anonClient.from('contacts').select('*');
// Expected: empty (RLS denies all reads to anon role unless you explicitly allow public reads)
```

6. **Repeat for every tenant-scoped table.** Templates, messages, conversations, calls, payments, audit_logs — all of them.

**Evidence (this is part of Gate A AND Gate D):**
- Test file showing all the cross-tenant attempts
- Test output: all isolation tests pass
- One specific output line per table: "✓ contacts: cross-tenant read denied"

**Done condition:** Every tenant table has at least one passing cross-tenant test in the suite. The suite runs in CI.

**Common failures:**
- Table has RLS enabled but no policy → 100% denied to authenticated role (overly restrictive; nothing works)
- Table has `USING` policy but no `WITH CHECK` policy → reads filter correctly, but a user can still INSERT a row with someone else's `tenant_id`
- JWT claim `tenant_id` not set → `auth.jwt() ->> 'tenant_id'` returns NULL → policy evaluates `NULL = NULL` which is NULL (falsy) → user sees nothing including their own data
- Service role key used in client code → bypasses ALL RLS → catastrophic. Service role belongs server-only, never in browser.
