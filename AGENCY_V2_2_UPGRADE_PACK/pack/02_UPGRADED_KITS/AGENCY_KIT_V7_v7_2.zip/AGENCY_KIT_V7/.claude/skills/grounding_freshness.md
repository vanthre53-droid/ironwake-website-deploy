# SKILL: grounding_freshness

**When to use:** EVERY project with an agent that quotes facts (prices/hours/policies/listings). The #1 confident-wrong-answer killer. Mandatory even single-agent.

**Reference:** v7.2 §33.5 + §33.4 `entities` schema (modules/39c-V7_2_UPGRADE_MODULE.md).

**Steps:**
1. Facts live ONLY in `entities` rows with `source_url` provenance + `valid_from/valid_until`.
2. `grounding_refresh` cron per tenant/source: on change, set old row `valid_until=now()` and INSERT the new — never UPDATE in place (history stays auditable).
3. Stale-block: source changed but refresh not landed → agent is blocked from quoting and uses the fallback line ("I'll have someone confirm that exact number").
4. Agents quote only rows where `valid_until IS NULL`.

**Evidence:** change a source price → superseded + inserted rows pasted → agent asked the old price re-grounds before answering.
