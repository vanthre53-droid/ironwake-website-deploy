# CLIENT CONTEXT

> Everything an AI dev tool needs to know about THIS client to make good decisions
> on their behalf. Filled in once at project kickoff; updated as relationship evolves.

## Identity
- **Legal entity:** <Sunrise Dental Clinic Pvt Ltd | Patel Real Estate LLC | etc.>
- **Brand name** (if different from legal): <"Sunrise Dental">
- **Tagline:** <"Anxiety-free dentistry for families">
- **Logo URL:** <link to brand asset>
- **Brand colors:** primary `#XXXXXX`, secondary `#XXXXXX`, accent `#XXXXXX`
- **Brand voice:** <warm + professional | bold + direct | playful + approachable | calm + reassuring>

## Business
- **Industry / niche:** <dental | HVAC | real estate | law | restaurant | salon | gym | other>
- **Locations:** <list of physical locations + service areas>
- **Service hours:** <Mon-Fri 9-6, Sat 10-2, closed Sun>
- **Languages:** primary + any secondary
- **Owner / decision-maker:** <name, contact, communication preference>
- **Day-to-day operator:** <name, contact — this is who the bot/agent answers to>

## Audience
- **Who the customer is:** <demographic + psychographic — 2-3 sentences>
- **Where they come from:** <Google Maps | walk-ins | Instagram | referrals | CTWA ads>
- **Common questions** (the ones the bot/agent must handle well):
  1. <question> — <correct response strategy>
  2. <question> — <correct response strategy>
  3. <question> — <correct response strategy>
- **Edge cases / pain points:** <what's awkward to handle; how owner handles it today>

## Constraints
- **Compliance:** <PHI/HIPAA? legal privilege? Fair Housing Act? PCI? local data residency?>
- **What the bot must NEVER do:** <quote prices that aren't in the system; commit to availability that isn't confirmed; give medical/legal advice; share customer info with anyone but the customer>
- **What the bot MUST always do:** <disclose AI; offer human handoff on request; quote only DB prices; confirm before any booking>

## Tech stack on the client side
- **Existing CRM:** <HubSpot | GoHighLevel | Pipedrive | Salesforce | none>
- **Existing calendar:** <Google Calendar | Calendly | Acuity | proprietary>
- **Existing payment processor:** <Razorpay | Stripe | Square | cash-only>
- **Existing comms tools:** <WhatsApp Business app | dedicated landline | shared inbox>

## Commercial terms (do not paste into committed code; reference only)
- Setup fee: <amount>
- Monthly retainer: <amount>
- Payment terms: <50% upfront, 50% on Gate E pass | net-30 invoice | etc.>
- SLA: <response time, uptime target, on-call expectations>

## Communication preferences
- **Slack / WhatsApp / email** for day-to-day: <pick one>
- **Reporting cadence:** <weekly Monday 9am digest | monthly | on-demand>
- **Escalation channel:** <how to reach the owner if production is down>

## Relationship history
- <YYYY-MM-DD> — <event: kickoff call, signed contract, Gate A passed, soft launch, etc.>
