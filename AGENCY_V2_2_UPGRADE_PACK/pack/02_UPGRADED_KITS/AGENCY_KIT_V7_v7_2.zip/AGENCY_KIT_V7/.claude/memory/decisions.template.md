# DECISIONS LOG — architectural decision records (ADR)

> Each entry: what was decided, why, what was rejected, and the cost of changing later.

## ADR template
```
## <YYYY-MM-DD> — <short title of the decision>
**Context:** <what triggered this decision; constraints; what we needed to solve>
**Decision:** <what we chose>
**Alternatives considered:**
- <option A> — rejected because <reason>
- <option B> — rejected because <reason>
**Consequences:** <what this enables; what it constrains; what it costs to change later>
**Revisit if:** <conditions that would make us reconsider>
```

---

## Examples (delete after first real entry)

## 2026-01-15 — Supabase over Firebase for the data layer
**Context:** Project needs Postgres-style relations, RLS, and a low-friction admin UI for the client to view their data.
**Decision:** Supabase (Postgres + Auth + RLS + Storage).
**Alternatives considered:**
- Firebase — rejected: NoSQL doesn't fit our relational data; weaker RLS analogue (security rules); higher long-term lock-in.
- PlanetScale + Clerk + Cloudflare R2 — rejected: more moving parts, no single dashboard for the client to inspect.
**Consequences:** Pinned to Postgres; RLS becomes the security model; one vendor, one bill.
**Revisit if:** Client outgrows Supabase's hosted limits (~100K MAU) and needs self-host.

## 2026-01-16 — Claude over OpenAI for the AI layer
**Context:** Need strong long-context behavior + prompt caching + tool use; predictable pricing.
**Decision:** Anthropic Claude (Haiku 4.5 / Sonnet 4.6 / Opus 4.8 tiered routing).
**Alternatives considered:**
- OpenAI GPT-4o family — rejected: pricing volatility, less reliable tool-use in our tests.
- Gemini — rejected: weaker tool calling; no consumer brand recognition for clients.
**Consequences:** Anthropic API dependency; cost discipline matters (caching mandatory).
**Revisit if:** Anthropic API has >1% downtime in a billing month, or pricing shifts >2× current rates.
