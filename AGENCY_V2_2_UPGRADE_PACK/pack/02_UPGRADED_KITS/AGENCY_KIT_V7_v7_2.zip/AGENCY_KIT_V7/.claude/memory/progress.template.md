# PROGRESS — <project name>

> This file is the resume protocol. Every session starts by reading this. Every
> meaningful step ends by updating this. Stale = useless.

**Status:** <one of: scaffolded | building | gate-X-passed | deployed | maintenance>
**Last updated:** <YYYY-MM-DD HH:MM UTC>
**Current phase:** <DB | API | Pages | Security | Deploy>

---

## ✅ Completed
- [x] <step> — <one-line outcome> — <gate passed if applicable>

## 🟡 In progress
- [ ] <current step> — <what's done, what's left, blockers>

## 🔜 Up next
- [ ] <next step>
- [ ] <step after that>
- [ ] <step after that>

## ⛔ Blockers
- <description + what unblocks it + who needs to do it>

## 📜 Decisions log
- <YYYY-MM-DD> — <decision> — <why>

## 🚧 Open questions for the user
- <question that needs an answer before proceeding>

## 🔁 Reversions / things that didn't work
- <YYYY-MM-DD> — <what was tried> — <why it didn't work> — <what we did instead>

---

## Update rules
1. Move items between sections — don't delete history
2. Tick the box `[x]` when a step's gate passes
3. Add the gate name to the completed line: `Gate A passed (DB) — see commit abc1234`
4. Never claim "done" without the gate evidence linked
5. If a session ends mid-step, note exactly what's done and what's left so the next session resumes without re-discovery
